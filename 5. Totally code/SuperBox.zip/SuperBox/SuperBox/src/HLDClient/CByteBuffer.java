package HLDClient;

public class CByteBuffer {
    // 缓冲区最大值
    final int BUFFERMAXSIZE = 1024 * 10;

    // 缓冲区数组
    byte[] m_abyBuf;

    // 接收到的数据长度
    private int m_iRecvLength = 0;
    
    // 数组下标位置
    private int m_iPosition = 0;

    // 是否等待继续接收
    private boolean bWaitRecvRemain;
    
    public int GetPosition()
    {
        return m_iPosition; 
    }
    
    public void SetPosition(int value)
    {
    	 m_iPosition = value; 
    }
    
    public int GetRecvLength()
    {
        return m_iRecvLength; 
    }
    
    public boolean GetWaitRecvRemain()
    {
       return bWaitRecvRemain;
    }
    
    public CByteBuffer()
    {
        m_abyBuf = new byte[BUFFERMAXSIZE];
    }

    public CByteBuffer(int bufferMaxSize)
    {
        m_abyBuf = new byte[bufferMaxSize];
    }

    // 将数据压入缓冲数组
    public void Put(byte[] aby, int offset, int len)
    {
    	// 溢出清理
        if (m_iRecvLength + len >= BUFFERMAXSIZE)
        {
            Clear();
            return;
        }
        System.arraycopy(aby, offset, m_abyBuf, m_iRecvLength, len);
        m_iRecvLength += len;
    }

    // 获取单个字节数据
    public byte GetByte()
    {
        byte byRet;

        bWaitRecvRemain = false;
        if (m_iPosition + 1 > m_iRecvLength)
        {
            bWaitRecvRemain = true;
            return 0;
        }
        byRet = m_abyBuf[m_iPosition];
        m_iPosition++;

        return byRet;
    }

    // 获取指定长度的字节数组
    public byte[] GetByteArray(int Length)
    {
    	 bWaitRecvRemain = false;
         if (m_iPosition + Length > m_iRecvLength)
         {
             bWaitRecvRemain = true;
             return null;
         }

         byte[] ret = new byte[Length];

         System.arraycopy(m_abyBuf, m_iPosition, ret, 0, Length);

         m_iPosition += Length;

         return ret;
    }

    public boolean HasRemaining()
    {
        return m_iPosition < m_iRecvLength;
    }

    private int Remaining()
    {
        return m_iRecvLength - m_iPosition;
    }

    public void Clear()
    {
        m_iPosition = 0;
        m_iRecvLength = 0;
        bWaitRecvRemain = false;
    }
}
