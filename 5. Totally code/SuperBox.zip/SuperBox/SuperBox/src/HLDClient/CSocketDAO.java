package HLDClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import mydata.CDataHelper;
import txt.CTxtHelp;

public class CSocketDAO {
    Socket m_socket;
    String m_strip = "127.0.0.1";
    int m_iport = 0;
            
    static boolean m_bConnection;
    static boolean m_bExit;
    static boolean m_bFirst = true;
    static boolean m_bHasStop = false;
    InputStream inputStream = null;
    java.io.OutputStream outputStream = null;
    public long lastRecvTime;
    public int outTime = 2 * 60 * 1000;// 3分钟未接收到数据认定链路断开(心跳包client <-> server,一应一答)
    
    CByteBuffer m_bufferRecv = new CByteBuffer();
    CProtocolHandle m_handle = new CProtocolHandle();
    CProtocolAnalysis m_analysis = new CProtocolAnalysis();
    
    public CSocketDAO(String ip, int port) {
        m_strip = ip;
        m_iport = port;
        (new Thread(new HeartThread())).start();
    }
    
    class HeartThread implements Runnable {
        @Override
        public void run() {
            int interval = 1000 * 30;
            
            while (true) {
                try { 
                    if (!m_bConnection) ConnectServer();// 自动重连
                    if (m_bConnection) Send(GetProtocol(CDataMgr.DeviceID, 1, ""));// 心跳包发送
                } catch (Exception ex)  { CTxtHelp.AppendLog("[Error] [CSocketDAO]<HeartThread>:" + ex.getMessage()); }
                
                try { Thread.sleep(interval); }  catch (InterruptedException e)  {}
            }
        }
    }
    
    public boolean ConnectServer() {
        m_bConnection = false;

        try {
            InetAddress addr = InetAddress.getByName(m_strip);  
            m_socket = new Socket();  
            m_socket.connect(new InetSocketAddress(addr, m_iport), 10000);
          
            m_bConnection = true; 
            m_bExit = false;
            if (m_bFirst) {
                m_bFirst = false;
                WriteLog("提示:后台通讯连接成功", false);
            }
            if (m_bHasStop) {
                WriteLog("提示:后台通讯连接成功", false);
            }
            m_bufferRecv.Clear();
            lastRecvTime = System.currentTimeMillis();
            (new Thread(new ReadThread(m_socket))).start();// 接收线程开启
            Send(GetProtocol(CDataMgr.DeviceID, 2, ""));// 时间同步
        } 
        catch (IOException e) {
            if (m_bFirst) {
                m_bFirst = false; 
                m_bHasStop = true;
                WriteLog("提示:后台通讯连接失败", true);
            }
        }   

        return m_bConnection;
    }
        
    public void StopConnection(String err) {
        if (!m_bConnection) return;
        m_bConnection = false;
        m_bExit = true;// 结束线程
        m_bHasStop = true;
        
        try { m_socket.shutdownInput(); } catch (IOException e) {}       
        try { m_socket.shutdownOutput(); } catch (IOException e) {}       
        try { m_socket.close(); } catch (IOException e) {}

        m_socket = null;
        
        try {
            inputStream.close();
            outputStream.close();
        } catch (IOException ex) {
        }

        WriteLog("提示:后台通讯连接失败:" + err, true);
    }
    
    void WriteLog(String strErr, boolean bErr) {
        CTxtHelp.AppendLog((bErr ? "[Error] " : "[Info] ") + strErr);
        CDataMgr.MainHandle.ofrmStandBy.PacketInput_NetState(strErr);
        UI.CSystemDAO.getInstance().AddWebLog(UI.CBaseEnum.SystemLog_Error_Net1, strErr);
    }
   
    // 读取网口数据线程
    class ReadThread implements Runnable
    {
        public Socket m_socket;

        public ReadThread(Socket socket) {
            m_socket = socket;
        }

        @Override
        public void run()
        {
            byte[] readBuffer = new byte[1024];
            
            while (!m_bExit)
            {
                if (!m_bConnection) return;

                try { 
                    inputStream = m_socket.getInputStream();
                    int iSize = inputStream.read(readBuffer);
                    if (iSize > 0) {
                        lastRecvTime = System.currentTimeMillis();
                        m_bufferRecv.Put(readBuffer, 0, iSize);
                    } 
                    else {
                        StopConnection("recv: size == 0");// 侦测用
                        break;
                    }
                    
                    m_analysis.BagStatus = CProtocolAnalysis.EBagStatus.BagNone;
                    
                    // 粘包处理
                    while (m_bufferRecv.HasRemaining())
                    {
                        // 掉包处理
                        if (CProtocolAnalysis.EBagStatus.BagLost == m_analysis.BagStatus) break;

                        m_handle.Process(m_bufferRecv, m_analysis, "");// 数据解析(垃圾包处理) 

                        if (m_analysis.WhetherToSend)
                        {
                            Send(GetProtocol(m_analysis));
                        }
                    }
                } 
                catch (IOException ex) {
                    StopConnection("recv: " + ex.getMessage());
                    break;
                }   
            }
        }
    }
    
    public boolean Send( byte[] data) {
        if (!m_bConnection) return false;
    
        if ((System.currentTimeMillis() - lastRecvTime) >= outTime) {
            StopConnection("recv: Over Time");
            return false;
        }
        
        try {
            outputStream = m_socket.getOutputStream();
            outputStream.write(data, 0, data.length); 
            outputStream.flush();
        } 
        catch (Exception ex) {
            StopConnection("send:" + ex.getMessage());// 由发送失败进行链路判断
            return false;
        }
        
        return true;
    }
    
    public byte[] GetProtocol(String uid, int cmd, String msg)
    {
        String content = CProtocolHandle.SPLIT1 + uid + CProtocolHandle.SPLIT1 +
                        System.currentTimeMillis() + CProtocolHandle.SPLIT1 +
                        CCommondFunc.lpad(cmd, 2) + CProtocolHandle.SPLIT1 +
                        msg + CProtocolHandle.SPLIT1;
        StringBuilder data = new StringBuilder();
        data.append("IOT=");
        data.append(CCommondFunc.lpad(CCommondFunc.GetStringLength(content), 4));
        data.append(content);
        return CDataHelper.StringToByte(data.toString());
    }
    
    public byte[] GetProtocol(CProtocolAnalysis analysis)
    {
        String content = CProtocolHandle.SPLIT1 + analysis.Uid + CProtocolHandle.SPLIT1 +
                        analysis.TaskId + CProtocolHandle.SPLIT1 +
                        CCommondFunc.lpad(analysis.Cmd, 2) + CProtocolHandle.SPLIT1 +
                        analysis.Msg + CProtocolHandle.SPLIT1;
        StringBuilder data = new StringBuilder();
        data.append("IOT=");
        data.append(CCommondFunc.lpad(CCommondFunc.GetStringLength(content), 4));
        data.append(content);
        return CDataHelper.StringToByte(data.toString());
    }
}
