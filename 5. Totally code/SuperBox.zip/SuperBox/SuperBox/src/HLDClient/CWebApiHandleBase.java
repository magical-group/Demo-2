package HLDClient;

import DB.CDBHelper;
import FuncClass.CDataMgr;
import UI.CBaseEnum;
import func.CCommondFunc;
import rest.CRestHelper;
import rest.PostResult;

public class CWebApiHandleBase {
    
    public static String SPLIT = "#";
    
    // 日志接口
    public static void Process6000(String orderid, long tmeStamp, String timeValue, int logtype, String content)
    {
        int ywbh = 6000;
        StringBuilder bodyData = new StringBuilder();
        bodyData.append(String.valueOf(ywbh)).append(SPLIT); // 业务编号
        bodyData.append(CDataMgr.DeviceID).append(SPLIT);    // E邮柜代号
        bodyData.append(CDataMgr.DeviceName).append(SPLIT);  // E邮柜别名
        bodyData.append(orderid).append(SPLIT);              // 订单编号
        bodyData.append(String.valueOf(tmeStamp)).append(SPLIT);    // 时间戳
        bodyData.append(timeValue).append(SPLIT);                   // 时间
        bodyData.append(String.valueOf(logtype)).append(SPLIT);     // 日志类型
        bodyData.append(content).append(SPLIT);                     // 日志内容
        final String data = bodyData.toString();
        CCommondFunc.AddRest_Process(data); 
    }
    
    // 投递员认证
    public static void Process6001(final CBaseEnum.Auth step)
    {
        int ywbh = 6001;
        StringBuilder bodyData = new StringBuilder();
        bodyData.append(String.valueOf(ywbh)).append(SPLIT); // 业务编号
        bodyData.append(CDataMgr.DeviceID).append(SPLIT);    // E邮柜代号
        bodyData.append(CDataMgr.TDYPhone).append(SPLIT);    // 手机号
        bodyData.append(CDataMgr.TDYPwd).append(SPLIT);      // 校验码
        bodyData.append(String.valueOf(step.ordinal())).append(SPLIT);// 认证标志0：动态密码 1：认证
        final String data = bodyData.toString();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    CBaseEnum.FormCase current = CDataMgr.MainHandle.GetCurFormCase();
                    if ((step == CBaseEnum.Auth.Step1 && (CBaseEnum.FormCase.Form_DeliverLogin != current && CBaseEnum.FormCase.Form_PwdInput != current)) ||
                       (step == CBaseEnum.Auth.Step2 && CBaseEnum.FormCase.Form_PwdInput != current))
                    {
                        break;// 超时退出
                    }
                    PostResult entity = CRestHelper.Process(CDataMgr.RestUrl_Process, data);
                    if (entity.IsSuccess) {
                        String info = entity.Info;
                        String err = entity.ErrMsg;
                        if (0 != err.length()) {
                            // 错误提示
                            switch (step) {
                                case Step1: 
                                    if (CBaseEnum.FormCase.Form_DeliverLogin == current) CDataMgr.MainHandle.ofrmDeliverLogin.PacketInput_KDYRZ(err); 
                                    if (CBaseEnum.FormCase.Form_PwdInput == current) CDataMgr.MainHandle.ofrmPwdInput.PacketInput(err); 
                                    break;
                                case Step2: CDataMgr.MainHandle.ofrmPwdInput.PacketInput(err); break;
                            }
                        }
                        else {
                            String[] contentItems = info.split(SPLIT);
                            switch (step) {
                                case Step1:
                                    // 投递员认证1：发送动态码
                                    CDataMgr.LocalPwdType = 6;
                                    CDataMgr.TDYMM = contentItems[3];
                                    if (CBaseEnum.FormCase.Form_PwdInput != current) 
                                    {
                                        //CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_PwdInput, CBaseEnum.RedirectType.Redirect_Next, null);
                                        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverSelect, CBaseEnum.RedirectType.Redirect_Next, null);
                                    }
                                    break;
                                case Step2:
                                    // 投递员认证2：返回认证信息
                                    CDataMgr.KDGS = contentItems[3];
                                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverSelect, CBaseEnum.RedirectType.Redirect_Next, null);
                                    break;
                            }
                        }
                        break;// 结束退出
                    }
                }
            }
        }).start();
    }  
    
    public static void Process6002(String xlh, String ddbh, String gkbh, int ddzt, String td, String qj, String tdsj, String qjsj, String beizhu)
    {
        int ywbh = 6002;
        StringBuilder bodyData = new StringBuilder();
        bodyData.append(String.valueOf(ywbh)).append(SPLIT); // 业务编号
        bodyData.append(CDataMgr.DeviceID).append(SPLIT);    // E邮柜代号
        bodyData.append(CDataMgr.DeviceName).append(SPLIT);  // E邮柜名称
        bodyData.append(xlh).append(SPLIT);                  // 序列号
        bodyData.append(ddbh).append(SPLIT);                 // 订单编号
        bodyData.append(gkbh).append(SPLIT);                 // 格口编号
        bodyData.append(ddzt).append(SPLIT);                 // 订单状态
        bodyData.append(td).append(SPLIT);                   // 投递员
        bodyData.append(qj).append(SPLIT);                   // 取件人
        bodyData.append(tdsj).append(SPLIT);                 // 投递时间
        bodyData.append(qjsj).append(SPLIT);                 // 取件时间
        bodyData.append(beizhu).append(SPLIT);               // 备注
        final String data = bodyData.toString();
        CCommondFunc.AddRest_Process(data); 
    }
    
    // 发送取件密码
    public static void Process6003(String ddbh, String gkbh, int bz)
    {
        int ywbh = 6003;
        StringBuilder bodyData = new StringBuilder();
        bodyData.append(String.valueOf(ywbh)).append(SPLIT); // 业务编号
        bodyData.append(CDataMgr.DeviceID).append(SPLIT);    // E邮柜代号
        bodyData.append(ddbh).append(SPLIT);                 // 订单编号
        bodyData.append(gkbh).append(SPLIT);                 // 格口编号
        final String data = bodyData.toString();
        if (0 == bz)
        {
            CCommondFunc.AddRest_Process(data); 
        }
        else
        {
            // 重发短信
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        CBaseEnum.FormCase current = CDataMgr.MainHandle.GetCurFormCase();
                        if (CBaseEnum.FormCase.Form_CFDX != current) break;// 超时退出
                        PostResult entity = CRestHelper.Process(CDataMgr.RestUrl_Process, data);
                        if (entity.IsSuccess) {
                            String info = entity.Info;
                            String err = entity.ErrMsg;
                            CDataMgr.MainHandle.ofrmCFDX.PacketInput(err);
                            if (0 == err.length()) {
                                String[] contentItems = info.split(SPLIT);
                                String ygbh = contentItems[1];// 邮柜编号
                                String jdbh = contentItems[2];// 订单编号
                                String gkbh = contentItems[3];// 格口编号
                                String qjmm = FuncClass.CCommondFunc.GetMD5(contentItems[4]);// 取件密码
                                CDBHelper.getInstance().Execute("update tb_Order set fs_QJMM='" + qjmm + "' where fi_DeviceID=" + ygbh + " and fi_BoxID=" + gkbh + " and fs_OrderID='" + jdbh + "' and fi_Status=" + CBaseEnum.Package_DeliverComplete);
                            }
                            break;// 结束退出
                        }
                    }
                }
            }).start();
        }
    } 
    
    // 远程协助
    public static void Process6004(String ddbh, int gkbh, final int ddzt,String sjhm, String tdm)
    {
        int ywbh = 6004;
        StringBuilder bodyData = new StringBuilder();
        bodyData.append(String.valueOf(ywbh)).append(SPLIT);    // 业务编号
        bodyData.append(CDataMgr.DeviceID).append(SPLIT);       // E邮柜代号
        bodyData.append(String.valueOf(ddbh)).append(SPLIT);    // 订单编号
        bodyData.append(String.valueOf(gkbh)).append(SPLIT);    // 格口编号
        bodyData.append(String.valueOf(ddzt)).append(SPLIT);    // 订单状态
        bodyData.append(String.valueOf(sjhm)).append(SPLIT);    // 取件手机号
        bodyData.append(String.valueOf(tdm)).append(SPLIT);     // 动态码
        final String data = bodyData.toString();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    CBaseEnum.FormCase current = CDataMgr.MainHandle.GetCurFormCase();
                    if (current != CBaseEnum.FormCase.Form_YCXZ) break;// 超时退出
                    PostResult entity = CRestHelper.Process(CDataMgr.RestUrl_Process, data);
                    if (entity.IsSuccess) {
                        String info = entity.Info;
                        String err = entity.ErrMsg;
                        if (0 != err.length()) {
                            // 错误提示
                            CDataMgr.MainHandle.ofrmYCXZ.PacketInput(err, ""); 
                        }
                        else {
                            String[] contentItems = info.split(SPLIT);
                            String ygbh = contentItems[1];// 邮柜编号
                            String gkbh = contentItems[2];// 格口编号
                            String jdbh = contentItems[3];// 订单编号
                            String xzmm = FuncClass.CCommondFunc.GetMD5(contentItems[4]);// 取件密码
                            CDataMgr.MainHandle.ofrmYCXZ.PacketInput(err, xzmm); 
                        }
                        break;// 结束退出
                    }
                }
            }
        }).start();
    }
}
