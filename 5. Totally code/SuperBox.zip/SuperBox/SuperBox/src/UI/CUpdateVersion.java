package UI;

import DB.CDBHelper;
import DB.QueryEntity;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import java.sql.ResultSet;
import java.sql.SQLException;
import net.sf.json.JSONArray;
import rest.CRestHelper;
import txt.CTxtHelp;

public class CUpdateVersion {
    
    public static void Execute(StringBuffer strMsg) {
        if (null == strMsg) 
            strMsg = new StringBuffer();
        else
            strMsg.delete(0, strMsg.length());
        
        CreatesStruct();
        UpdateData(strMsg);
    }
    
    static void AddTestData() {
        CDBHelper.getInstance().Execute("insert into tb_Order (fs_OrderID,fi_DeviceID) values ('hldordertest','" + CDataMgr.DeviceID + "')");
        CDBHelper.getInstance().Execute("insert into tb_box (fi_BoxID,fi_DeviceID) values (0,'" + CDataMgr.DeviceID + "')");
    }
    
    static void DeleteTestData() {
        CDBHelper.getInstance().Execute("delete from tb_Order Where fs_OrderID='hldordertest' and fi_DeviceID=" + CDataMgr.DeviceID);
        CDBHelper.getInstance().Execute("delete from tb_box Where fi_BoxID=0 and fi_DeviceID=" + CDataMgr.DeviceID);
    }
    
    static void CreatesStruct() {
        CTxtHelp.AppendLog("[Info] 配齐数据库结构...");
        String strSql = ""; String[] ColumnNameItems = null;
   
        AddTestData();
        
        strSql = "select * from tb_Order limit 0,1";
        ColumnNameItems = CCommondFunc.GetTableColumn(strSql);
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_DispatcherPwd")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_DispatcherPwd varchar(10)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems, "fs_XZMM")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_XZMM varchar(100)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_LXQJ")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_LXQJ varchar(1)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_ZZDD")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_ZZDD varchar(1)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_CJGL")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_CJGL varchar(1)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_QJGL")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_QJGL varchar(1)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_SJBH")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_SJBH varchar(10)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_WLBH")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_WLBH varchar(50)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_DDMS")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_DDMS varchar(5000)");
//        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems,"fs_JYLSH")) CDBHelper.getInstance().Execute("alter table tb_Order add column fs_JYLSH varchar(50)");

        strSql = "select * from tb_box limit 0,1";
        ColumnNameItems = CCommondFunc.GetTableColumn(strSql);
        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems, "fs_FGBH")) CDBHelper.getInstance().Execute("alter table tb_box add column fs_FGBH varchar(10)");
        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems, "fs_GKWZ")) CDBHelper.getInstance().Execute("alter table tb_box add column fs_GKWZ varchar(10)");
        if (!CCommondFunc.IsTableHasColumn(ColumnNameItems, "fi_FaultCount")) CDBHelper.getInstance().Execute("alter table tb_box add column fi_FaultCount int default 0");

        strSql = "select fi_ID from tb_Agree limit 0,1";
        ColumnNameItems = CCommondFunc.GetTableColumn(strSql);
        if (null == ColumnNameItems) {
            CDBHelper.getInstance().Execute("CREATE TABLE [tb_Agree] (" +
                      "[fi_ID] INTEGER NOT NULL ON CONFLICT FAIL PRIMARY KEY ON CONFLICT FAIL, " +
                      "[fi_XYLX] VARCHAR(10), " +
                      "[fi_XYBB] VARCHAR(10), " +
                      "[fi_XYNR] VARCHAR(8000))");

            String msg = "";
            msg = "E邮站（柜）存件协议\r\n" +
            "在使用本E邮柜前，请您务必事先阅读本协议内容，如您不接受其中的任何条款，请不要使用本柜存件；在您实际使用本柜后就视为您已经充分知悉并全部接 受本协议的所有条款。\r\n" +
            "1、本柜仅授权经过E邮站管理部门登记注册的人员进行存件操作。\r\n" +
            "2、存件人存件前须确保已经事先告知收件人并征得其同意使用本柜投递物品。\r\n" +
            "3、存件人使用本柜存件，即视为自愿使用本柜存件，自愿遵守本协议的使用规定和接受本协议的使用条件。\r\n" +
            "4、禁止使用本柜存入我国相关法律法规禁止流通或寄存的物品。我国法律法规禁止流通或者寄递的物品包括但不限于武器、弹药、麻醉药物、生化制品、传 染性物 品和爆炸性、易燃性、腐蚀性、放射性、毒性等危险物品及含有反动、淫秽或有伤风化内容的报刊书籍、图片、宣传品、音像制品、激光视盘（VCD、 DVD、LD）、计算机磁盘及光盘等。\r\n" +
            "5、具有以下情形的物品，禁止存入本柜：\r\n" +
            "（1）收件人明确要求本人当面签收的物品；\r\n" +
            "（2）超出本柜容纳体积的物品；\r\n" +
            "（3）贵重（包括但不限于电脑、现金、珠宝等）物品、价值超过3000元人民币（含）的物品；\r\n" +
            "（4）保价金额超过3000元人民币的物品；\r\n" +
            "（5）时限紧急、内容重要的物品；\r\n" +
            "（6）易碎物品或包裹包装已经破损、变形、水湿的物品；\r\n" +
            "（7）易变质、易腐烂的物品；\r\n" +
            "（8）电话号码及地址填写不清楚的物品；\r\n" +
            "（9）货到付款或者到付费用的物品；\r\n" +
            "6、一个箱子一次只能存入一个快递。 \r\n" +
            "7、凡是投递到本柜中的快件，按照快递员存入快件与业主取出快件相同的原则。\r\n" +
            "8、存入本柜的物品包装外观是否破损、变形、水湿，包装内的物品是否是寄件人托运的物品、是否损坏等全部责任均由承运该物品的电商或投递公司及存件 人负责。\r\n" +
            "9、本柜采用即时短信方式通知收件人，由于存件人输错手机号码，或者短信延迟、丢失及其他情形导致收件人未及时收取物品的，由过错方承担赔偿责任，E 邮站不承担赔偿责任。\r\n" +
            "10、严禁采取任何方式破坏、非授权方式打开本柜，盗取他人物品或者个人信息，违者将追究法律责任。\r\n" +
            "11、乙方及其所属的快递员在进入安装有e邮站的小区时，应遵守该小区的物业管理规范。\r\n" +
            "12、因不可抗力（“不可抗力”指不能预见、不能避免和不能克服的客观情况，包括但不限于政府行为、主管部门政策变化、战争、地震、台风、洪水、火灾 等其他类似事件）造成物品损伤的，E邮站不承担赔偿责任。 \r\n" +
            "13、存件人须严格按照本协议的约定使用E邮站系统，因存件人自己过错造成的损失，E邮站不承担赔偿责任。\r\n" +
            "14、使用过程中有任何疑问，请与E邮站24小时服务热线11185联系。";
            CDBHelper.getInstance().Execute("insert into tb_Agree(fi_XYLX, fi_XYBB, fi_XYNR) values ('01', '100004', '" + msg + "')");

            msg = "1、请核对短信中的取件地址是否与本柜地址相符；\r\n2、取件后请检查箱内是否有遗留物品并及时关闭箱门；\r\n3、取出物品后，请即现场验视物品外包装是否正常。遇有疑问时，请阅读《E邮站（柜）存件协议》并当即联系存件人或E邮站服务热线11185；\r\n4、遇设备异常导致无法取件时，请拨打E邮站服务热线11185求助。";
            CDBHelper.getInstance().Execute("insert into tb_Agree(fi_XYLX, fi_XYBB, fi_XYNR) values ('02', '100003', '" + msg + "')");
        }
        CDBHelper.getInstance().Execute("update tb_Agree set fi_XYBB='100004' where fi_XYLX='01'");
        CDBHelper.getInstance().Execute("update tb_Agree set fi_XYBB='100003' where fi_XYLX='02'");
        
        strSql = "select fi_ID from tb_BoxError limit 0,1";
        ColumnNameItems = CCommondFunc.GetTableColumn(strSql);
        if (null == ColumnNameItems) {
            CDBHelper.getInstance().Execute("CREATE TABLE [tb_BoxError] (" +
                            "[fi_ID] INTEGER NOT NULL ON CONFLICT FAIL PRIMARY KEY AUTOINCREMENT DEFAULT 0, " +
                            "[fi_DeviceID] VARCHAR(10), " +
                            "[fs_OrderID] VARCHAR(32), " +
                            "[fi_BoxID1] INT DEFAULT 0, " +
                            "[fi_BoxID2] INT DEFAULT 0, " +
                            "[fs_PID] VARCHAR(20), " +
                            "[fs_Pwd] VARCHAR(10), " +
                            "[fs_Time1] DATETIME, " +
                            "[fs_Time2] DATETIME, " +
                            "[fs_Note] VARCHAR(50), " +
                            "[fi_State] INT DEFAULT 0)");
        }


        strSql = "select fi_ID from tb_OffLineData limit 0,1";
        ColumnNameItems = CCommondFunc.GetTableColumn(strSql);
        if (null == ColumnNameItems)
        {
            CDBHelper.getInstance().Execute("CREATE TABLE [tb_OffLineData] (" +
                      "[fi_ID] INTEGER NOT NULL ON CONFLICT FAIL PRIMARY KEY ON CONFLICT FAIL AUTOINCREMENT, " +
                      "[fs_Data] VARCHAR(500))");
        }
        
        DeleteTestData();
    }
    
    static void UpdateData(StringBuffer strMsg) {
        // 改设备编号
        String deviceid_old = "";
        String strSql = ""; JSONArray jsonArr;
        
        strSql = "select fi_DeviceID from tb_Device limit 0,1";
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <UpdateData> sql=" + strSql); return ; }
        
        boolean update = false;
        ResultSet rs = result.dataRs;;
        try {
            if (rs.next()) {
                // 老设备编号判断
                deviceid_old = rs.getString("fi_DeviceID");
                if (null == deviceid_old || "".equals(deviceid_old) || "0".equals(deviceid_old)) {
                    strMsg.append("错误：本地终端数据库存在异常，请检查!!!");
                }
                else {
                    strSql ="select fi_DeviceID from tb_Device where fi_DeviceID=" + CDataMgr.DeviceID;
                    jsonArr = CRestHelper.GetDataTable(CDataMgr.RestUrl_GetDataTable, strSql);
                    if (null != jsonArr)  {
                        if (jsonArr.size() > 0) {
                            strMsg.append("错误：管理平台升已存在该设备编号，请检查!!!");
                        }
                        else {
                            update = true;
                        }
                    }
                }
            }
        } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally {
            CDBHelper.getInstance().closeQuery(result);
        }
        
        if (update) {
            func.CCommondFunc.SyncExecuteSql("update tb_box set fi_DeviceID=" + CDataMgr.DeviceID + " where fi_DeviceID=" + deviceid_old);
            func.CCommondFunc.SyncExecuteSql("update tb_Device set fi_DeviceID=" + CDataMgr.DeviceID + " where fi_DeviceID=" + deviceid_old);
            func.CCommondFunc.SyncExecuteSql("update tb_BoxEventLog set fi_DeviceID=" + CDataMgr.DeviceID + " where fi_DeviceID=" + deviceid_old);
            func.CCommondFunc.SyncExecuteSql("update tb_Order set fi_DeviceID=" + CDataMgr.DeviceID + " where fi_DeviceID=" + deviceid_old);

            CDBHelper.getInstance().Execute("delete from tb_BoxError");
            CDBHelper.getInstance().Execute("delete from tb_Card");
            CDBHelper.getInstance().Execute("delete from tb_Order");
            CDBHelper.getInstance().Execute("delete from tb_OffLineData");

            strMsg.append("升级成功");
        }
    }
}
