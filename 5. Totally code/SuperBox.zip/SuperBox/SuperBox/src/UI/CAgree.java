package UI;

import DB.CDBHelper;
import DB.QueryEntity;
import FuncClass.CDataMgr;
import java.sql.ResultSet;
import java.sql.SQLException;
import txt.CTxtHelp;

public class CAgree {
    
    static int type = -1;

    // 检测协议版本
    public static void CheckXYBB() {
//        if ("".equals(CDataMgr.getInstance().XYBBH)) return;
        
//        String oldsplit = "#@#";
//        String xybbh = CDataMgr.getInstance().XYBBH.replace(oldsplit, DataAnalysis.SPLITE_IN);
//        String[] items = xybbh.split(DataAnalysis.SPLITE_OUT);
//        type = -1;// -1：无动作;0:添加;1:修改
//        String strSql = ""; 
//
//        // 协议版本号判断
//        strSql = "select fi_XYLX, fi_XYBB, fi_XYNR from tb_Agree";
//        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
//        if (!result.hasData) { 
//            type = 0;
//        }
//        else {
//            ResultSet rs = result.dataRs;;
//            try {
//                while (rs.next()) {
//                    for (String item : items) {
//                        if (item.substring(0, 2).equals(rs.getString("fi_XYLX"))) {
//                            if (!item.substring(2).equals(rs.getString("fi_XYBB"))) {
//                                type = 1;
//                            }
//                        }
//                    }
//                }
//            } catch (SQLException ex) { }
//            finally {
//                CDBHelper.getInstance().closeQuery(result);
//            }
//        }
//
//        if (-1 != type) {
//            // 版本号不对，重新下载
//            CPacketHandle2.Process60045("01");// 屏蔽版本更新
//        }
    }

    public static void EventXYGX(String err, String xybbh, String xynr) {
        if (!"".equals(err)) {
            CTxtHelp.AppendLog("获取许可协议失败:" + err);
        }
        else{
            String xylx = xybbh.substring(0, 2);
            String xybb = xybbh.substring(2);

            String strSql = "";
            switch (type) {
                case 0:
                    strSql = "insert into tb_Agree (fi_XYLX, fi_XYBB,fi_XYNR) values('" + xylx + "','" + xybb + "','" + xynr + "')";
                    break;
                case 1:
                    strSql = "update tb_Agree set fi_XYBB='" + xybb + "',fi_XYNR='" + xynr + "' where fi_XYLX='" + xylx + "'";
                    break;
            }

            DB.CDBHelper.getInstance().Execute(strSql);
            
//            if ("01".equals(xylx)) {
//                CPacketHandle2.Process60045("02");
//            }
        }
    }
}
