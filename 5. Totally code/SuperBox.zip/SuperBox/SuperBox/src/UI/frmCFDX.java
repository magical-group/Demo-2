package UI;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import HLDClient.CWebApiHandleBase;
import static UI.CBaseEnum.KeyType.Key_BarCode;
import txt.CTxtHelp;

public class frmCFDX extends javax.swing.JPanel {
    
    CustomControl.TextBoxInput m_Curtxt;
    String m_CurTabIndex;
    boolean m_blNextClick = false;
    int index = 0;
    String orderid = "";
    String boxid = "";
    
    public frmCFDX() {
        initComponents();
        (new Thread(new RunTimeThread())).start();
    }
    
    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void ClearData() {
        txtOrderID.Clear();
        txtPhone.Clear();
        btnCFQJM.setEnabled(false);
        lblTipMsg.setText("...");
        orderid = "";
        boxid = "";
        m_blNextClick = false;
    }
    
    void VoiceTip() {
        CCommondFunc.VoiceTip("请输入从发取件密码信息");
    }
    
    void SetTextBox() {
        txtOrderID.SetTextBox(1, 20); 
        txtPhone.SetTextBox(2, 11);
        m_CurTabIndex = "1";
        m_Curtxt = txtOrderID;
        
        txtOrderID.setFocusable(true);
    }
    
    class RunTimeThread implements Runnable {
        @Override
        public void run() {
            while (true) {
                if (index <= 0) {
                    btnCFQJM.setText("重新获取取件密码");
                    btnCFQJM.setEnabled(true);
                }
                else {
                    btnCFQJM.setText("重新获取取件密码(" + (index--) +")");
                }
                
                try { Thread.sleep(1000); }  catch (InterruptedException e)  {}
            }
        }
    }
    
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        if (m_blNextClick) return ;
        
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        if (eKeyType == CBaseEnum.KeyType.Key_TEXTBOX_FORCECHANGE || eKeyType == CBaseEnum.KeyType.Key_UP || eKeyType == CBaseEnum.KeyType.Key_DOWN) {
            AutoChangeForce(strInput);// 手动进行光标切换
        }
        else {
            // 按键信息
            switch (eKeyType) {
                case Key_BarCode:
                    txtOrderID.SetDefaultValue(strInput);
                    break;
                case Key_NUMBER:
                    // 自动进行光标切换
                    if (!"".equals(strInput)) {
                        if ("1".equals(m_CurTabIndex)) {
                            if (txtOrderID.GetText().trim().length() == 20 && txtOrderID_Validated()) {
                                m_CurTabIndex = "2";
                                m_Curtxt = txtPhone;// 验证通过自动跳转到下个文本框
                            }
                        }
                    }
                    m_Curtxt.InputText(strInput);
                    break;
                case Key_SPACE:
                    m_Curtxt.InputText(strInput);
                    if ("2".equals(m_CurTabIndex) && "".equals(txtPhone.GetText())) {
                        AutoChangeForce("1");// 焦点自动切换回上一个文本框
                    }
                    break;
                case Key_ENTER:
                    if (txtOrderID_Validated() && Phone_Validated() && CheckOrder()) {
                        if (btnCFQJM.isEnabled()) {
                            NextStep();// 验证通过自动调用下一步
                        }
                        else {
                            lblTipMsg.setText("请在倒计时结束后操作!");
                        }
                    }
                    break;
                case Key_ESC:
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
                    break;
            }
        }
    }
    
    void AutoChangeForce(String strInput) {
        m_CurTabIndex = strInput;
            
        switch (m_CurTabIndex) {
            case "1": m_Curtxt = txtOrderID; break;
            case "2": m_Curtxt = txtPhone; break;
            case CBaseEnum.PIN_PRESSED_UP:
            case CBaseEnum.PIN_PRESSED_DOWN:
                if (m_Curtxt == txtOrderID) {
                    m_CurTabIndex = "2"; m_Curtxt = txtPhone;
                }
                else {
                    m_CurTabIndex = "1"; m_Curtxt = txtOrderID;
                }
                break;
        }

        
        m_Curtxt.SetCursor();
    }

    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        if (eRedirectType != CBaseEnum.RedirectType.Redirect_Pre) {
            ClearData();
        }

        FuncClass.CBaseTime.StartTime(lblSeconds, 60);
        CDataMgr.AllKeyPadHandle = zTKeyPad1;// 加载全键盘
        SetTextBox();
        ClearData();
        VoiceTip();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        btnExit = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnPreStep = new javax.swing.JButton();
        zTKeyPad1 = new CustomControl.ZTKeyPad();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        lblOrder = new javax.swing.JLabel();
        txtOrderID = new CustomControl.TextBoxInput();
        lblPhone = new javax.swing.JLabel();
        txtPhone = new CustomControl.TextBoxInput();
        btnCFQJM = new javax.swing.JButton();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setBackground(new java.awt.Color(6, 57, 104));
        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("重发取件密码");

        btnExit.setBackground(new java.awt.Color(6, 57, 104));
        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTimeOut1.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setBackground(new java.awt.Color(6, 57, 104));
        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        lblTipMsg.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        lblOrder.setBackground(new java.awt.Color(6, 57, 104));
        lblOrder.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblOrder.setForeground(new java.awt.Color(255, 255, 255));
        lblOrder.setText("邮件号码");

        lblPhone.setBackground(new java.awt.Color(6, 57, 104));
        lblPhone.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblPhone.setForeground(new java.awt.Color(255, 255, 255));
        lblPhone.setText("用户手机号码");

        btnCFQJM.setFont(new java.awt.Font("微软雅黑", 1, 12)); // NOI18N
        btnCFQJM.setText("重新获取取件密码");
        btnCFQJM.setActionCommand("");
        btnCFQJM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCFQJMActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(zTKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(150, 150, 150)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblPhone)
                                    .addComponent(lblOrder))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnCFQJM, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(lblTitle)))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(lblTitle)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblOrder)
                        .addGap(26, 26, 26)
                        .addComponent(lblPhone))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(161, Short.MAX_VALUE)
                        .addComponent(txtOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCFQJM, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(zTKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPreStep, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))
                        .addGap(13, 13, 13)))
                .addGap(15, 15, 15))
        );

        lblTitle.getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ESC, "");
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnPreStepActionPerformed

    private void btnCFQJMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCFQJMActionPerformed
        // 重发取件密码
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ENTER, "");
    }//GEN-LAST:event_btnCFQJMActionPerformed

    boolean txtOrderID_Validated() {
        orderid = CCommondFunc.OrderID_Deal(txtOrderID.GetText().trim());
        return CCommondFunc.txtOrderID_Validated(orderid, " and fs_Phone='" + txtPhone.GetText().trim() + "' and fi_Status=" + CBaseEnum.Package_DeliverComplete, lblTipMsg, 1);
    }
        
    boolean Phone_Validated() {
        return CCommondFunc.Phone_Validated(txtPhone.GetText(), lblTipMsg, "用户手机号");
    }
    
    boolean CheckOrder() {
        CBoxProperty property = CCommondFunc.GetOrderBox(orderid, txtPhone.GetText());
        if (null == property) {
            lblTipMsg.setText("查无包裹信息,请确认输入信息!");
            return false;
        }
        boxid = property.BoxID;
        return true;
    }
    
    void NextStep() {
        CTxtHelp.AppendLog("[Info] ===============================================================");
        CTxtHelp.AppendLog("[Info] UserPackageHelp");
        
        lblTipMsg.setText("发送中...");
        btnCFQJM.setEnabled(false);
        index = 30;
        m_blNextClick = true;
        CWebApiHandleBase.Process6003(orderid, boxid, 1);
    }
    
    public void PacketInput(String err) {
        m_blNextClick = false;
        
        if (!"".equals(err)) {
            lblTipMsg.setText("重发取件密码成失败:" + err);// 错误输出
        }
        else {
            lblTipMsg.setText("重发取件密码成功!");
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCFQJM;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnPreStep;
    private javax.swing.JLabel lblOrder;
    private javax.swing.JLabel lblPhone;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlTipMsg;
    private CustomControl.TextBoxInput txtOrderID;
    private CustomControl.TextBoxInput txtPhone;
    private CustomControl.ZTKeyPad zTKeyPad1;
    // End of variables declaration//GEN-END:variables
}
