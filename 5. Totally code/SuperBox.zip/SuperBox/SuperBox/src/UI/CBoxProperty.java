package UI;

public class CBoxProperty {
    public String BoxID;        // 格口号
    public String GKWZ;         // 格口位置
    public int Side;            // 继电器归属控制板(0:左边;1:右边)
    public int Relay;           // 继电器号
    public int BoxStatus;       // 格口状态
    public int LockStatus;      // 锁状态(1:开;2:关)
    public int TriggerType;     // 开箱类型
    public String TriggerID;    // 开箱者ID
    public int Infrared;        // 有物/无物
    public int Result;          // 开锁反馈 0:失败;1:成功;2:关闭，没有检测到包裹;3;关闭成功;4:有物提示
    public boolean Error;       // 打开格口是否与当前格口一致
    public int FaultCount;
    public CBaseEnum.BoxAction EBoxAction = CBaseEnum.BoxAction.Open;
    public String OrderID;      // 该格口正在使用的订单号
}
