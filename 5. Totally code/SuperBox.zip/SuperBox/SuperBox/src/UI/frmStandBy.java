package UI;

import FuncClass.CCommondFunc;
import java.awt.AWTEvent;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import FuncClass.CDataMgr;
import UI.CBaseEnum.KeyType;
import static UI.CBaseEnum.KeyType.Key_NUMBER;
import mydate.CDateHelper;

public class frmStandBy extends javax.swing.JPanel {

    long nexttime = 0;
    
    public frmStandBy() {
        initComponents();
        (new Thread(new RunTimeThread())).start();
    }
    
    class RunTimeThread implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    lblTime.setText(CDateHelper.GetNowTime());
                    
                    if (UI.CBaseEnum.SystemType.WINDOW == CDataMgr.ESystemType) {
                        if (System.currentTimeMillis() >= nexttime) { 
                            nexttime = System.currentTimeMillis() + 1000 * 60 * 1;
                            if (UI.CBaseEnum.FormCase.Form_StandBy == CDataMgr.MainHandle.GetCurFormCase()) {
                                FuncClass.TtsHelper.getInstance().speak("");// 空闲时发声
                            }
                        }
                    }
                }
                catch (Exception e)  {
                    String err = "计时器异常," + e.getMessage();
                    txt.CTxtHelp.AppendLog("[Error]" + err);
                    CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_SoftException, err);
                }
                
                try { Thread.sleep(1000); }  catch (InterruptedException e)  {}
            }
        }
    }
    
    public void TTkeyBoardInput(KeyType eKeyType, String strInput) {
        switch (eKeyType)
        {
            case Key_NUMBER:
                switch (strInput) {
                    case "1": btnUserActionPerformed(null); break;
                    case "2": btnDeliverActionPerformed(null); break;
                    case "3": btnCFQJMMActionPerformed(null); break;
                }
                break;
        }
    }
    
    boolean Haswatch = false;
    
    // 捕获用户键盘输入
    public void WatchUserKeyBoard() {
        // 程序焦点切换以捕获键盘输入
        if (Haswatch) return; Haswatch = true;
        
        Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {
            @Override
            public void eventDispatched(AWTEvent event) {
                if (((KeyEvent)event).getID() == KeyEvent.KEY_PRESSED) {
                    switch (((KeyEvent)event).getKeyCode()) {
                        // F5 进入管理后台
                        case KeyEvent.VK_F5:
                            txt.CTxtHelp.AppendLog("[Admin] 管理员进入终端后台");
                            CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_Device, CBaseEnum.RedirectType.Redirect_Next, null);
                            break;
                        // F6 鼠标控
                       case KeyEvent.VK_F6:
                            txt.CTxtHelp.AppendLog("[Admin] 管理员显示鼠标");
                            CDataMgr.MainHandle.SetCursorShow(true);
                            break;
                    }
                    Haswatch = false;
                    CDataMgr.MainHandle.setFocusable(false);
                    CDataMgr.MainHandle.setFocusable(true);
                }
            }
        }, AWTEvent.KEY_EVENT_MASK);
    }
    
    public void AdminIntoBackground(boolean flg, String msg) {
        if (flg) {
            btnUser.setEnabled(false);
            btnDeliver.setEnabled(false);
        }
        else {
            btnUser.setEnabled(true);
            btnDeliver.setEnabled(true);
        }
        lblTipMsg.setText(msg);
    }

    public void PacketInput_NetState(String content) {
        lblTipMsg.setText(content);
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        try {
            lblVerSion.setText(CDataMgr.SoftType + CDataMgr.SoftVerSion + "_" + CDataMgr.DeviceID);

            CDataMgr.MainHandle.setAlwaysOnTop(true);

            if (oParam != null) {
                CFormPassParam param = (CFormPassParam)oParam;
                if (param.GetFormSource() == CBaseEnum.FormCase.Form_PackagePutResult) {
                    if (CDataMgr.LocalPwdType != 9 && CDataMgr.LocalPwdType != 10) {
                        // 快递员投件超时
                        if (CDataMgr.CurrentBoxHasOpen){
                             CLogicHandle.onPackagePutSuccess(CDataMgr.CurrentBoxID, 1, param.tigMsg);// 格口开启成功超时，添加到订单
                             lblTipMsg.setText("投递员存件超时,存件成功!");
                        }
                    }
                    else {
                        lblTipMsg.setText("操作完成后请关好箱门,谢谢合作!");
                    }
                }
                else {
                    lblTipMsg.setText(param.tigMsg);// 其他信息
                }
            }
            else {
                lblTipMsg.setText("操作完成后请关好箱门,谢谢合作!");
            }

            // 取件完成还有物品登记
            switch (CDataMgr.CurrentAction) {
                case 2:
                    if (0 == FuncClass.CCommondFunc.IsInfrared("and fi_BoxID=" + CDataMgr.CurrentBoxID))
                        UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_Operation, "快递员取件完,格口还有包裹;格口:" + CDataMgr.CurrentBoxID);
                    break;
                case 3:
                    if (0 == FuncClass.CCommondFunc.IsInfrared("and fi_BoxID=" + CDataMgr.CurrentBoxID))
                        UI.CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_Operation, "用户取件完,格口还有包裹;格口:" + CDataMgr.CurrentBoxID);
                    break;
            }

            btnUser.setEnabled(true);
            btnDeliver.setEnabled(true);
            CSystemDAO.getInstance().CloseBarCode();

            WatchUserKeyBoard();

            // 数据重置
            FuncClass.CCommondFunc.EndOrder();
            CDataMgr.IsTDY = false;
            CDataMgr.SupperManGet = false;
            CDataMgr.TDYDTM = "";
        }
        catch (Exception e)  {
            String err = "页面跳转异常,StandBy:" + e.getMessage();
            txt.CTxtHelp.AppendLog("[Error]" + err);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblMain = new javax.swing.JLabel();
        btnUser = new javax.swing.JButton();
        btnDeliver = new javax.swing.JButton();
        lblTitle = new javax.swing.JLabel();
        lblTime = new javax.swing.JLabel();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        lblVerSion = new javax.swing.JLabel();
        btnCFQJMM = new javax.swing.JButton();

        setBackground(new java.awt.Color(6, 57, 104));

        lblMain.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/StandBy_Main.jpg"))); // NOI18N

        btnUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/StandBy_User.png"))); // NOI18N
        btnUser.setMaximumSize(new java.awt.Dimension(305, 150));
        btnUser.setMinimumSize(new java.awt.Dimension(305, 150));
        btnUser.setPreferredSize(new java.awt.Dimension(305, 150));
        btnUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserActionPerformed(evt);
            }
        });

        btnDeliver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/StandBy_Deliver.png"))); // NOI18N
        btnDeliver.setMaximumSize(new java.awt.Dimension(305, 150));
        btnDeliver.setMinimumSize(new java.awt.Dimension(305, 150));
        btnDeliver.setPreferredSize(new java.awt.Dimension(305, 150));
        btnDeliver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeliverActionPerformed(evt);
            }
        });

        lblTitle.setFont(new java.awt.Font("微軟正黑體", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("24小时日夜守候,无论多晚,我都等你");
        lblTitle.setToolTipText("");

        lblTime.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblTime.setForeground(new java.awt.Color(255, 255, 255));
        lblTime.setText("1970-00-0 00:00:00");

        lblTipMsg.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("操作完成后请关好箱门,谢谢合作!");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 835, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        lblTipMsg.getAccessibleContext().setAccessibleName("");

        lblVerSion.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblVerSion.setForeground(new java.awt.Color(255, 255, 255));
        lblVerSion.setText("LINUX_ZJYZ_V1.0.0.1");

        btnCFQJMM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/重发密码.png"))); // NOI18N
        btnCFQJMM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCFQJMMActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(111, 111, 111)
                .addComponent(lblVerSion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTime)
                .addGap(116, 116, 116))
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(106, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblTitle)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCFQJMM, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblMain)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnUser, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDeliver, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(79, 79, 79))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(194, 194, 194)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblTitle)
                    .addComponent(btnCFQJMM, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnDeliver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblMain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTime)
                    .addComponent(lblVerSion))
                .addGap(15, 15, 15))
        );

        lblVerSion.getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserActionPerformed
        txt.CTxtHelp.AppendLog("[button] 取件");
        // 用户操作
        CDataMgr.IsTDY = false;
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_Agree, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnUserActionPerformed

    private void btnDeliverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeliverActionPerformed
        txt.CTxtHelp.AppendLog("[button] 快递员");
        // 快递员操作
        CDataMgr.IsTDY = true;
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_Agree, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnDeliverActionPerformed

    private void btnCFQJMMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCFQJMMActionPerformed
        txt.CTxtHelp.AppendLog("[button] 重发取件密码");
        // 重发取件密码
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_CFDX, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnCFQJMMActionPerformed

    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCFQJMM;
    private javax.swing.JButton btnDeliver;
    private javax.swing.JButton btnUser;
    private javax.swing.JLabel lblMain;
    private javax.swing.JLabel lblTime;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblVerSion;
    private javax.swing.JPanel pnlTipMsg;
    // End of variables declaration//GEN-END:variables
}
