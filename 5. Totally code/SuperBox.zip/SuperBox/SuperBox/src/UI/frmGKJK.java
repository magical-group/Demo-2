package UI;

import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;

public class frmGKJK extends javax.swing.JPanel {

    String msg = "";
    
    public frmGKJK() {
        initComponents();
    }
    
    void Refresh(String title, String strWhere) {
        msg = title + "\r\n" + CCommondFunc.GetDeviceMsg() + "\r\n";
        msg += CCommondFunc.GetBoxMsg(strWhere);
        rtbMsg.setText(msg);
    }
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        FuncClass.CBaseTime.StartTime(lblSeconds, 120);
        Refresh("所有格口", null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        btnExit = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        rtbMsg = new javax.swing.JTextArea();
        btnRefresh = new javax.swing.JButton();
        btnKXYW = new javax.swing.JButton();
        btnGZGK = new javax.swing.JButton();
        btnPreStep = new javax.swing.JButton();
        btnGZGK1 = new javax.swing.JButton();
        btnSYZ = new javax.swing.JButton();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("格口监控");

        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("600");

        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        rtbMsg.setEditable(false);
        rtbMsg.setColumns(20);
        rtbMsg.setFont(new java.awt.Font("微软雅黑", 0, 14)); // NOI18N
        rtbMsg.setRows(5);
        jScrollPane1.setViewportView(rtbMsg);

        btnRefresh.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        btnRefresh.setText("刷新");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnKXYW.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        btnKXYW.setText("空闲有物");
        btnKXYW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKXYWActionPerformed(evt);
            }
        });

        btnGZGK.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        btnGZGK.setText("故障");
        btnGZGK.setActionCommand("");
        btnGZGK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGZGKActionPerformed(evt);
            }
        });

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        btnGZGK1.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        btnGZGK1.setLabel("在柜订单");
        btnGZGK1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGZGK1ActionPerformed(evt);
            }
        });

        btnSYZ.setFont(new java.awt.Font("宋体", 1, 18)); // NOI18N
        btnSYZ.setText("使用中");
        btnSYZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSYZActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnKXYW, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnGZGK, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(btnSYZ, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnGZGK1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 858, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(91, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnKXYW, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGZGK, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGZGK1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSYZ, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        // 刷新
        Refresh("所有格口", null);
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnKXYWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKXYWActionPerformed
        // 空闲有物
        Refresh("空闲有物", "and fi_BoxStatus=" + CBaseEnum.BoxStatus.Box_Ideal.ordinal() + " and fi_Infrared=" + CBaseEnum.Infrared.HasThing.ordinal());
    }//GEN-LAST:event_btnKXYWActionPerformed

    private void btnGZGKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGZGKActionPerformed
        // 故障
        Refresh("故障", "and fi_BoxStatus=3");
    }//GEN-LAST:event_btnGZGKActionPerformed

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_Device, CBaseEnum.RedirectType.Redirect_Next, null);
    }//GEN-LAST:event_btnPreStepActionPerformed

    private void btnGZGK1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGZGK1ActionPerformed
        msg = "在柜包裹" + "\r\n" + CCommondFunc.GetDeviceMsg() + "\r\n";
        msg += CCommondFunc.GetOrderMsg("and fi_Status=" + CBaseEnum.Package_DeliverComplete); 
        rtbMsg.setText(msg);
    }//GEN-LAST:event_btnGZGK1ActionPerformed

    private void btnSYZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSYZActionPerformed
        // 使用中
        Refresh("使用中", "and fi_BoxStatus=2");
    }//GEN-LAST:event_btnSYZActionPerformed
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnGZGK;
    private javax.swing.JButton btnGZGK1;
    private javax.swing.JButton btnKXYW;
    private javax.swing.JButton btnPreStep;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnSYZ;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextArea rtbMsg;
    // End of variables declaration//GEN-END:variables
}
