package UI;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import static UI.CBaseEnum.KeyType.Key_TEXTBOX_FORCECHANGE;
import txt.CTxtHelp;

public class frmDeliverStep2 extends javax.swing.JPanel {

    CustomControl.TextBoxInput m_Curtxt;
    String m_CurTabIndex;
    boolean m_blAllowInput = true;
    
    public frmDeliverStep2() {
        initComponents();
    }

    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void ClearData() {
        lblOrderID.setText(CDataMgr.TDYOrderID);
        lblTipMsg.setText("...");
        txtPhone1.Clear();
        txtPhone2.Clear();
        txtPhone1.setEnabled(true);
        txtPhone2.setEnabled(true);
    }
    
    void VoiceTip() {
        CCommondFunc.VoiceTip("请输入用户手机号码");
    }
    
    void SetTextBox() {
        txtPhone1.SetTextBox(1, 11);
        txtPhone2.SetTextBox(2, 11);
            
        m_CurTabIndex = "1";
        m_Curtxt = txtPhone1;
        
        txtPhone1.setFocusable(true);
    }
    
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        if (!m_blAllowInput) return;// 不允许输入
        
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        if (eKeyType == CBaseEnum.KeyType.Key_TEXTBOX_FORCECHANGE || eKeyType == CBaseEnum.KeyType.Key_UP || eKeyType == CBaseEnum.KeyType.Key_DOWN) {
            AutoChangeForce(strInput); // 手动进行光标切换
        }
        else {
            // 按键信息
            switch (eKeyType) {
                case Key_NUMBER:
                    if ("1".equals(m_CurTabIndex)) {
                        if (txtPhone1.GetText().trim().length() == 11 && Phone_Validated(txtPhone1, "手机号码")) {
                            m_CurTabIndex = "2";
                            m_Curtxt = txtPhone2; // 验证通过自动跳转到下个文本框
                        }
                    }
                    m_Curtxt.InputText(strInput);
                    if ("2".equals(m_CurTabIndex)) {
                        if (Phone_Validated(txtPhone1, "手机号码") && Phone_Validated(txtPhone2, "重复号码") && Phone_Compare()) {
                            NextStep();// 验证通过自动调用下一步
                        }
                    }
                    break;
                case Key_SPACE:
                    m_Curtxt.InputText(strInput);
                    if ("2".equals(m_CurTabIndex) && "".equals(txtPhone2.GetText())) {
                        AutoChangeForce("1");// 焦点自动切换回上一个文本框
                    }
                    break;
                case Key_ENTER:
                    if (Phone_Validated(txtPhone1, "手机号码") && Phone_Validated(txtPhone2, "重复号码") && Phone_Compare()) {
                        NextStep();// 验证通过自动调用下一步
                    }
                    break;
                case Key_ESC:
                    CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
                    break;
            }
        }
    }
    
    void AutoChangeForce(String strInput) {
        m_CurTabIndex = strInput;
            
        switch (m_CurTabIndex) {
            case "1": m_Curtxt = txtPhone1; break;
            case "2": m_Curtxt = txtPhone2; break;
            case CBaseEnum.PIN_PRESSED_UP:
            case CBaseEnum.PIN_PRESSED_DOWN:
                if (m_Curtxt == txtPhone1) {
                    m_CurTabIndex = "2"; m_Curtxt = txtPhone2;
                }
                else {
                    m_CurTabIndex = "1"; m_Curtxt = txtPhone1;
                }
                break;
        }
        
        m_Curtxt.SetCursor();
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        if (eRedirectType != CBaseEnum.RedirectType.Redirect_Pre) {
            ClearData();
        }
        
        SetTextBox();
        
        FuncClass.CBaseTime.StartTime(lblSeconds, 60);
        
        m_blAllowInput = true;
        
        lblUser.setVisible(false);
        
        VoiceTip();
    }
    
    boolean Phone_Validated(CustomControl.TextBoxInput txtPhone, String flg) {
        return CCommondFunc.Phone_Validated(txtPhone.GetText(), lblTipMsg, flg);
    }
    
    boolean Phone_Compare() {
        if (!txtPhone1.GetText().equals(txtPhone2.GetText())) {
            lblTipMsg.setText("两次输入手机号码不一致，请重新输入！");
            return false;
        }
        
        return true;
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnPreStep = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        lblUser = new javax.swing.JLabel();
        txtPhone1 = new CustomControl.TextBoxInput();
        lblPhone2 = new javax.swing.JLabel();
        txtPhone2 = new CustomControl.TextBoxInput();
        lblPhone1 = new javax.swing.JLabel();
        lblOrderID = new javax.swing.JLabel();
        numberKeyPad1 = new CustomControl.NumberKeyPad();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("输入用户手机号码");

        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblUser.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblUser.setForeground(new java.awt.Color(240, 240, 240));
        lblUser.setText("(用户名:)");

        lblPhone2.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblPhone2.setForeground(new java.awt.Color(255, 255, 255));
        lblPhone2.setText("重复号码:");

        lblPhone1.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblPhone1.setForeground(new java.awt.Color(255, 255, 255));
        lblPhone1.setText("手机号码:");

        lblOrderID.setFont(new java.awt.Font("微软雅黑", 0, 30)); // NOI18N
        lblOrderID.setForeground(new java.awt.Color(255, 0, 0));
        lblOrderID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOrderID.setText("45123451234512345023");

        lblTipMsg.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(lblTitle)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblUser, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(247, 247, 247)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblPhone1)
                                    .addGap(23, 23, 23)
                                    .addComponent(txtPhone1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(lblPhone2)
                                    .addGap(23, 23, 23)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(numberKeyPad1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txtPhone2, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(125, 125, 125)
                                .addComponent(lblOrderID)))))
                .addContainerGap(182, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTitle)
                    .addComponent(lblUser))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(lblOrderID)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtPhone1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(lblPhone1)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(lblPhone2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(txtPhone2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(numberKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblTimeOut1)
                                .addComponent(lblSeconds)
                                .addComponent(lblTimeOut2))
                            .addGap(13, 13, 13)))
                    .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
        );

        lblUser.getAccessibleContext().setAccessibleName("");
        lblOrderID.getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverStep1, CBaseEnum.RedirectType.Redirect_Pre, null);
    }//GEN-LAST:event_btnPreStepActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ESC, "");
    }//GEN-LAST:event_btnExitActionPerformed
    
    void NextStep() {
        CDataMgr.YHPhone = txtPhone1.GetText();
        CTxtHelp.AppendLog("[UI] DeliverStep2,UserPhone=" + CDataMgr.YHPhone);
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_DeliverStep3, CBaseEnum.RedirectType.Redirect_Next, new CFormPassParam(CBaseEnum.FormCase.Form_DeliverStep2, null, ""));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnPreStep;
    private javax.swing.JLabel lblOrderID;
    private javax.swing.JLabel lblPhone1;
    private javax.swing.JLabel lblPhone2;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblUser;
    private CustomControl.NumberKeyPad numberKeyPad1;
    private javax.swing.JPanel pnlTipMsg;
    private CustomControl.TextBoxInput txtPhone1;
    private CustomControl.TextBoxInput txtPhone2;
    // End of variables declaration//GEN-END:variables
}
