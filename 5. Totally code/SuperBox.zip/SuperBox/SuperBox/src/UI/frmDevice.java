package UI;

import DB.CDBHelper;
import DB.QueryEntity;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import static UI.CBaseEnum.KeyType.Key_TEXTBOX_FORCECHANGE;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import mydate.CDateHelper;
import txt.CTxtHelp;

public class frmDevice extends javax.swing.JPanel {

    CustomControl.TextBoxInput m_Curtxt;
    String m_CurTabIndex;
    String m_strFlg = "U";
    
    int GXFG_OK = 0; int GXFG_ERR = 0;
    int XZFG_OK = 0; int XZFG_ERR = 0;
    int XZDD_OK = 0; int XZDD_ERR = 0;
    volatile boolean IsOpenLocking = false;
    
    public frmDevice() {
        initComponents();
        
        SetTextBox();
    }
    
    void ClearData() {
        GXFG_OK = GXFG_ERR = XZFG_OK = XZFG_ERR = XZDD_OK = XZDD_ERR = 0;
        m_strFlg = "A";
        SetTextBox();
        btnSupperManGet.setVisible(true);
        lblTipMsg.setText("...");
    }
    
    void SetTextBox() {
        txtStart.SetTextBox(1, 3);txtStart.SetDefaultValue("1");
        txtEnd.SetTextBox(2, 3);txtEnd.SetDefaultValue("1");
        m_CurTabIndex = "1";
        m_Curtxt = txtStart;
    }
     
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        if (eKeyType == Key_TEXTBOX_FORCECHANGE) {
            // 手动进行光标切换
            m_CurTabIndex = strInput;
            
            switch (m_CurTabIndex) {
                case "1": m_Curtxt = txtStart; break;
                case "2": m_Curtxt = txtEnd; break;
            }
        }
        else {
            // 按键信息
            switch (eKeyType) {
                case Key_NUMBER:
                    m_Curtxt.InputText(strInput);
                    break;
                case Key_SPACE:
                    m_Curtxt.InputText(strInput);
                    break;
                case Key_ENTER:
                    break;
            }
        }
    }
        
    public void PacketInput(String content) {
        // 失败
        if (content.contains("GXSB_CW")) {
            lblTipMsg.setText("[设备信息] 更新失败:" + content);
        }
        else if (content.contains("GXFG_CW")) {
            lblTipMsg.setText("[副柜信息] 更新失败:" + content + ",成功数:" + GXFG_OK + ",错误数:" + (++GXFG_ERR));
        }
        else if (content.contains("XZFG_CW")) {
            lblTipMsg.setText("[副柜信息] 下载失败:" + content + ",成功数:" + XZFG_OK + ",错误数:" + (++XZFG_ERR));
        }
        else if (content.contains("XZDD_CW")) {
            lblTipMsg.setText("[订单信息] 下载失败:" + content + ",成功数:" + XZDD_OK + ",错误数:" + (++XZDD_ERR));
        }
        // 成功
        else if (content.contains("GXSB_CG")) {
            lblTipMsg.setText("[设备信息] 更新成功:" + content);
        }
        else if (content.contains("GXFG_CG")) {
            lblTipMsg.setText("[副柜信息] 更新成功:" + content + ",成功数:" + (++GXFG_OK) + ",错误数:" + GXFG_ERR);
        }
        else if (content.contains("XZFG_CG")) {
            lblTipMsg.setText("[副柜信息] 下载成功:" + content + ",成功数:" + (++XZFG_OK) + ",错误数:" + XZFG_ERR);
        }
        else if (content.contains("XZDD_CG")) {
            if (content.contains("MSG_ING"))
                lblTipMsg.setText("[订单信息] 下载成功:" + content + ",成功数:" + (++XZDD_OK) + ",错误数:" + XZDD_ERR);
            else if (content.contains("MSG_END"))
                lblTipMsg.setText("[订单信息] 下载成功:" + content + ",成功数:" + (XZDD_OK) + ",错误数:" + XZDD_ERR);
        }
    }
    
     public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        lblTitle.setText("设备管理(" + CDataMgr.DeviceID + ")");
        ClearData();
        FuncClass.CBaseTime.StartTime(lblSeconds, 300);
    }
     
    public void ShowTipMsg(String content) {
        lblTipMsg.setText(content);
        CTxtHelp.AppendLog("[UI] " + lblTipMsg.getText());
    } 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        numberKeyPad1 = new CustomControl.NumberKeyPad();
        btnSJCZ = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        lblLeftCount1 = new javax.swing.JLabel();
        txtStart = new CustomControl.TextBoxInput();
        lblRightCount1 = new javax.swing.JLabel();
        txtEnd = new CustomControl.TextBoxInput();
        btnOpenLock = new javax.swing.JButton();
        btnSupperManGet = new javax.swing.JButton();
        btnVideo = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnGKJK = new javax.swing.JButton();
        btnCQRJ = new javax.swing.JButton();
        btnGKXF = new javax.swing.JButton();
        btnDDQC = new javax.swing.JButton();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("设备管理");

        btnSJCZ.setBackground(new java.awt.Color(255, 0, 51));
        btnSJCZ.setText("数据重整(点击后请等待操作结束)");
        btnSJCZ.setActionCommand("");
        btnSJCZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSJCZActionPerformed(evt);
            }
        });

        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTipMsg.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 859, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        lblLeftCount1.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblLeftCount1.setForeground(new java.awt.Color(255, 255, 255));
        lblLeftCount1.setText("起始格口:   ");

        lblRightCount1.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblRightCount1.setForeground(new java.awt.Color(255, 255, 255));
        lblRightCount1.setText("截止格口:");

        btnOpenLock.setText("开 锁");
        btnOpenLock.setActionCommand("");
        btnOpenLock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOpenLockActionPerformed(evt);
            }
        });

        btnSupperManGet.setText("超级管理员取件");
        btnSupperManGet.setActionCommand("");
        btnSupperManGet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupperManGetActionPerformed(evt);
            }
        });

        btnVideo.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        btnVideo.setText("监控视频");
        btnVideo.setActionCommand("");
        btnVideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVideoActionPerformed(evt);
            }
        });

        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("600");

        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnGKJK.setFont(new java.awt.Font("微软雅黑", 0, 12)); // NOI18N
        btnGKJK.setText("格口监控");
        btnGKJK.setActionCommand("");
        btnGKJK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGKJKActionPerformed(evt);
            }
        });

        btnCQRJ.setBackground(new java.awt.Color(255, 0, 51));
        btnCQRJ.setLabel("重启软件");
        btnCQRJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCQRJActionPerformed(evt);
            }
        });

        btnGKXF.setLabel("所有故障格口已修复");
        btnGKXF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGKXFActionPerformed(evt);
            }
        });

        btnDDQC.setBackground(new java.awt.Color(255, 0, 51));
        btnDDQC.setText("订单清除");
        btnDDQC.setActionCommand("");
        btnDDQC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDDQCActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblRightCount1)
                            .addComponent(lblLeftCount1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtEnd, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(txtStart, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(btnSupperManGet)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnOpenLock, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(numberKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSJCZ, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
                    .addComponent(btnGKXF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDDQC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCQRJ, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnVideo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGKJK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(185, 185, 185))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(lblTitle)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblLeftCount1)
                            .addComponent(txtStart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(lblRightCount1))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtEnd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(numberKeyPad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSupperManGet, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnOpenLock, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(66, 66, 66))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(btnCQRJ, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSJCZ, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDDQC, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(btnVideo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnGKXF, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnGKJK, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(90, 90, 90)))
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))))
                .addGap(15, 15, 15))
        );

        lblLeftCount1.getAccessibleContext().setAccessibleName("");
        lblRightCount1.getAccessibleContext().setAccessibleName("");
        btnOpenLock.getAccessibleContext().setAccessibleName("");
        lblSeconds.getAccessibleContext().setAccessibleName("");
        btnCQRJ.getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnSJCZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSJCZActionPerformed
        lblTipMsg.setText("数据重整中...");
        
        // 数据库清理
        CTxtHelp.AppendLog("[UI] 数据库清理");
        CDBHelper.getInstance().Execute("delete from tb_Box");
        CDBHelper.getInstance().Execute("delete from tb_BoxError");
        CDBHelper.getInstance().Execute("delete from tb_Card");
        CDBHelper.getInstance().Execute("delete from tb_Device");
        CDBHelper.getInstance().Execute("delete from tb_BoxEventLog");
        CDBHelper.getInstance().Execute("delete from tb_OffLineData");
        CDBHelper.getInstance().Execute("delete from tb_Order");
        //生成设备表
        CTxtHelp.AppendLog("[UI] 生成设备表");
        CDBHelper.getInstance().Execute("insert into tb_Device ([fi_DeviceID], [fs_Name]) values ('"+ CDataMgr.DeviceID + "','')");
        // 新老版本升级
//        CTxtHelp.AppendLog("[UI] 新老版本升级");
//        CUpdateVersion.Execute(new StringBuffer());

        CTxtHelp.AppendLog("[UI] 同步格口及订单信息");
        CCommondFunc.UpdateDeviceFromServer();
        
        lblTipMsg.setText("重整结束,请在 [格口监控] 查看!");
    }//GEN-LAST:event_btnSJCZActionPerformed

    private void btnOpenLockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOpenLockActionPerformed
        if (IsOpenLocking) {
            IsOpenLocking = false;
            btnOpenLock.setText("开 锁");
            return;
        }
        
        btnOpenLock.setText("停 止");
        IsOpenLocking = true;
        
        CTxtHelp.AppendLog("[Info] ===============================================================");
        
        // 开锁
        final int boxidstart = Integer.parseInt(txtStart.GetText());
        final int boxidend = Integer.parseInt(txtEnd.GetText());
        
        // 为了显示刷新效果
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int boxid = boxidstart; boxid <= boxidend; boxid++) {
                    if (!IsOpenLocking) break;
                    CBoxProperty property = CCommondFunc.GetBox1(String.valueOf(boxid));
                    CLogicHandle.OpenBox(property, CBaseEnum.Lock_ManualOpen, "Manual", CBaseEnum.Action_GLYQJ, "管理员开锁");
                }
                btnOpenLock.setText("开 锁");
                IsOpenLocking = false;
            }
        }).start();
    }//GEN-LAST:event_btnOpenLockActionPerformed

    private void btnSupperManGetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupperManGetActionPerformed
        CDataMgr.SupperManGet = true;
        btnSupperManGet.setVisible(false);
        lblTipMsg.setText("取件动作将以超级管理员身份通知到服务器!!!");
    }//GEN-LAST:event_btnSupperManGetActionPerformed

    private void btnVideoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVideoActionPerformed
        CDataMgr.MainHandle.setAlwaysOnTop(false);// 窗体置前
        
        // 监控视频
        switch (CDataMgr.ESystemType) {
             case WINDOW:
                try { Runtime.getRuntime().exec(System.getProperty("user.dir") + java.io.File.separator + "soft" + java.io.File.separator + "lib" + java.io.File.separator + "DVRTest.exe"); } catch (IOException ex) { };
                break;
             case LINUX:
                try { Runtime.getRuntime().exec("./" + "DVRStart.sh"); } catch (IOException ex) { };
                break;
        } 
    }//GEN-LAST:event_btnVideoActionPerformed

    private void btnGKJKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGKJKActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_GKJK, CBaseEnum.RedirectType.Redirect_Null, null);
    }//GEN-LAST:event_btnGKJKActionPerformed

    private void btnCQRJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCQRJActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnCQRJActionPerformed

    private void btnGKXFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGKXFActionPerformed
        lblTipMsg.setText("正在修正终端故障格口信息...");
        
        // 所有故障格口已修复并同步
        String strWhere = " where fi_DeviceID=" + CDataMgr.DeviceID + " and fi_BoxStatus=" + CBaseEnum.BoxStatus.Box_Fault.ordinal();
        func.CCommondFunc.SyncExecuteSql("update tb_Box set fs_Content='终端修复故障格口[" + CDateHelper.GetNowTime() + "]',fi_FaultCount=0,fi_BoxStatus=" + CBaseEnum.BoxStatus.Box_Ideal.ordinal() + strWhere);
        lblTipMsg.setText("故障格口已设为空闲");
    }//GEN-LAST:event_btnGKXFActionPerformed

    private void btnDDQCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDDQCActionPerformed
        CDBHelper.getInstance().Execute("delete from tb_Order");
        lblTipMsg.setText("本地订单已清除");
    }//GEN-LAST:event_btnDDQCActionPerformed
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCQRJ;
    private javax.swing.JButton btnDDQC;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnGKJK;
    private javax.swing.JButton btnGKXF;
    private javax.swing.JButton btnOpenLock;
    private javax.swing.JButton btnSJCZ;
    private javax.swing.JButton btnSupperManGet;
    private javax.swing.JButton btnVideo;
    private javax.swing.JLabel lblLeftCount1;
    private javax.swing.JLabel lblRightCount1;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private CustomControl.NumberKeyPad numberKeyPad1;
    private javax.swing.JPanel pnlTipMsg;
    private CustomControl.TextBoxInput txtEnd;
    private CustomControl.TextBoxInput txtStart;
    // End of variables declaration//GEN-END:variables
}
