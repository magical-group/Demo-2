package UI;

import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import txt.CTxtHelp;

public class frmDeliverStep3 extends javax.swing.JPanel {
 
    boolean rechoose;
    CFormPassParam param;
    boolean m_blNextClick = false;

    public frmDeliverStep3() {
        initComponents();
        
        SetButtonEnable(false);
    }

    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void ClearData() {
        rechoose = false;
        param = null;
        m_blNextClick = false;
        btnPreStep.setEnabled(true);
        lblTipMsg.setText("...");
    }
    
    void VoiceTip() {
        CCommondFunc.VoiceTip("请选择格口大小");
    }
    
    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        if (m_blNextClick) return;
        
        FuncClass.CBaseTime.ReSetTime();
        
        switch (eKeyType)
        {
            case Key_NUMBER:
                switch (strInput) {
                    case "1": if (btnBigBox.isEnabled()) btnBigBoxActionPerformed(null); break;
                    case "2": if (btnNormalBox.isEnabled()) btnNormalBoxActionPerformed(null); break;
                    case "3": if (btnSmallBox.isEnabled()) btnSmallBoxActionPerformed(null); break;
                    case "4": if (btnSBigBox.isEnabled()) btnSBigBoxActionPerformed(null); break;
                    case "5": if (btnSSmallBox.isEnabled()) btnSSmallBoxActionPerformed(null); break;
                }
                break;
        }
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        ClearData();
        FuncClass.CBaseTime.StartTime(lblSeconds, 90);
        VoiceTip();
        
        param = (CFormPassParam)oParam;
        if (CBaseEnum.FormCase.Form_PackagePutResult == param.GetFormSource()) {
             // 重选格口跳转过来
            rechoose = true;
            FuncClass.CBaseTime.StartTimeWithParam(lblSeconds, 90, 0 , CBaseEnum.FormCase.Form_StandBy, new CFormPassParam(CBaseEnum.FormCase.Form_PackagePutResult, null, "重新格口超时"));
            InitUsedableBox(true);
        }
        else {
            InitUsedableBox(false);
        }
    }
    
    void InitUsedableBox(boolean refresh) {
        SetButtonEnable(false);
        int[] BoxCountItem = CCommondFunc.GetBoxRemain();
        lblBigBox.setText("① 剩余" + CCommondFunc.lpad(BoxCountItem[0], 2) + "个");
        lblNormalBox.setText("② 剩余" + CCommondFunc.lpad(BoxCountItem[1], 2) + "个");
        lblSmallBox.setText("③ 剩余" + CCommondFunc.lpad(BoxCountItem[2], 2) + "个");
        lblSBigBox.setText("④ 剩余" + CCommondFunc.lpad(BoxCountItem[3], 2) + "个");
        lblSSmallBox.setText("⑤ 剩余" + CCommondFunc.lpad(BoxCountItem[4], 2) + "个");
        if (BoxCountItem[0] != 0) { btnBigBox.setEnabled(true); }
        if (BoxCountItem[1] != 0) { btnNormalBox.setEnabled(true); }
        if (BoxCountItem[2] != 0) { btnSmallBox.setEnabled(true); }
        if (BoxCountItem[3] != 0) { btnSBigBox.setEnabled(true); }
        if (BoxCountItem[4] != 0) { btnSSmallBox.setEnabled(true); }
    }
    
    public void ShowTipMsg(String content) {
        lblTipMsg.setText(content);
        CTxtHelp.AppendLog("[UI] " + lblTipMsg.getText());
    } 
    
    void SetButtonEnable(boolean enable) {
        btnBigBox.setEnabled(enable);
        btnNormalBox.setEnabled(enable);
        btnSmallBox.setEnabled(enable);
        btnSBigBox.setEnabled(enable);
        btnSSmallBox.setEnabled(enable);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnPreStep = new javax.swing.JButton();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        pnlDo = new javax.swing.JPanel();
        lblDo = new javax.swing.JLabel();
        btnExit = new javax.swing.JButton();
        btnBigBox = new javax.swing.JButton();
        lblBigBox = new javax.swing.JLabel();
        btnSBigBox = new javax.swing.JButton();
        lblSBigBox = new javax.swing.JLabel();
        btnNormalBox = new javax.swing.JButton();
        lblNormalBox = new javax.swing.JLabel();
        btnSmallBox = new javax.swing.JButton();
        lblSmallBox = new javax.swing.JLabel();
        btnSSmallBox = new javax.swing.JButton();
        lblSSmallBox = new javax.swing.JLabel();

        setBackground(new java.awt.Color(6, 57, 104));
        setPreferredSize(new java.awt.Dimension(1024, 768));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("选择格口大小");

        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("90");

        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        lblTipMsg.setFont(new java.awt.Font("黑体", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(185, 185, 185)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        pnlDo.setBackground(new java.awt.Color(15, 68, 120));

        lblDo.setFont(new java.awt.Font("黑体", 0, 24)); // NOI18N
        lblDo.setForeground(new java.awt.Color(255, 0, 0));
        lblDo.setText("...");

        javax.swing.GroupLayout pnlDoLayout = new javax.swing.GroupLayout(pnlDo);
        pnlDo.setLayout(pnlDoLayout);
        pnlDoLayout.setHorizontalGroup(
            pnlDoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDoLayout.createSequentialGroup()
                .addGap(405, 405, 405)
                .addComponent(lblDo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDoLayout.setVerticalGroup(
            pnlDoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDoLayout.createSequentialGroup()
                .addComponent(lblDo)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.setEnabled(false);
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        btnBigBox.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/大箱子.jpg"))); // NOI18N
        btnBigBox.setEnabled(false);
        btnBigBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBigBoxActionPerformed(evt);
            }
        });

        lblBigBox.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblBigBox.setForeground(new java.awt.Color(255, 255, 255));
        lblBigBox.setText("① 剩余00个");

        btnSBigBox.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/超大箱子.jpg"))); // NOI18N
        btnSBigBox.setEnabled(false);
        btnSBigBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSBigBoxActionPerformed(evt);
            }
        });

        lblSBigBox.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSBigBox.setForeground(new java.awt.Color(255, 255, 255));
        lblSBigBox.setText("④ 剩余00个");

        btnNormalBox.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/中箱子.jpg"))); // NOI18N
        btnNormalBox.setEnabled(false);
        btnNormalBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNormalBoxActionPerformed(evt);
            }
        });

        lblNormalBox.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblNormalBox.setForeground(new java.awt.Color(255, 255, 255));
        lblNormalBox.setText("② 剩余00个");

        btnSmallBox.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/小箱子.jpg"))); // NOI18N
        btnSmallBox.setEnabled(false);
        btnSmallBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSmallBoxActionPerformed(evt);
            }
        });

        lblSmallBox.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSmallBox.setForeground(new java.awt.Color(255, 255, 255));
        lblSmallBox.setText("③ 剩余00个");

        btnSSmallBox.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/超小箱子.jpg"))); // NOI18N
        btnSSmallBox.setEnabled(false);
        btnSSmallBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSSmallBoxActionPerformed(evt);
            }
        });

        lblSSmallBox.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSSmallBox.setForeground(new java.awt.Color(255, 255, 255));
        lblSSmallBox.setText("⑤ 剩余00个");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnlDo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblSBigBox)
                                    .addComponent(btnSBigBox, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(284, 284, 284))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnBigBox, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(lblBigBox)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblNormalBox)
                                        .addGap(49, 49, 49))
                                    .addComponent(btnNormalBox, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(50, 50, 50)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lblSmallBox)
                                .addComponent(btnSmallBox, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnSSmallBox, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblSSmallBox))))
                .addGap(171, 171, 171))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addGap(49, 49, 49)
                .addComponent(pnlDo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBigBox, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblBigBox))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnNormalBox, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblNormalBox))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSmallBox, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSmallBox)))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSSmallBox, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblSSmallBox))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSBigBox, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblSBigBox)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))
                        .addGap(24, 24, 24))))
        );

        lblBigBox.getAccessibleContext().setAccessibleName("");
        lblNormalBox.getAccessibleContext().setAccessibleName("");
        lblSmallBox.getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        CDataMgr.MainHandle.OnEventShowForm(param.GetFormSource(), CBaseEnum.RedirectType.Redirect_Pre, null);
    }//GEN-LAST:event_btnPreStepActionPerformed

    private void btnBigBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBigBoxActionPerformed
        SetButtonEnable(false);
        OpenBox(CBaseEnum.BoxSize.Box_Big);
    }//GEN-LAST:event_btnBigBoxActionPerformed

    private void btnNormalBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNormalBoxActionPerformed
        SetButtonEnable(false);
        OpenBox(CBaseEnum.BoxSize.Box_Normal);
    }//GEN-LAST:event_btnNormalBoxActionPerformed

    private void btnSmallBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSmallBoxActionPerformed
        SetButtonEnable(false);
        OpenBox(CBaseEnum.BoxSize.Box_Small);
    }//GEN-LAST:event_btnSmallBoxActionPerformed

    private void btnSBigBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSBigBoxActionPerformed
        SetButtonEnable(false);
        OpenBox(CBaseEnum.BoxSize.Box_SBig);
    }//GEN-LAST:event_btnSBigBoxActionPerformed

    private void btnSSmallBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSSmallBoxActionPerformed
       SetButtonEnable(false);
       OpenBox(CBaseEnum.BoxSize.Box_SSmall);
    }//GEN-LAST:event_btnSSmallBoxActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ESC, "");
    }//GEN-LAST:event_btnExitActionPerformed
    
    void OpenBox(CBaseEnum.BoxSize eBoxSize) {
        if (m_blNextClick) return; m_blNextClick = true;
        
        FuncClass.CBaseTime.ReSetTime();
        
        btnPreStep.setEnabled(false);
 
        lblTipMsg.setText("正在打开格口中...");

        String strWhere = " and fi_BoxStatus=" + CBaseEnum.BoxStatus.Box_Ideal.ordinal() + " and fi_Infrared=" + CBaseEnum.Infrared.NoThing.ordinal() + " and fi_BoxID not in (select fi_BoxID from tb_Order where fi_status=" + CBaseEnum.Package_DeliverComplete + ");";
        CBoxProperty property = CCommondFunc.GetUsedableBox(eBoxSize, strWhere);

        if (null == property) {
            lblTipMsg.setText("该格口编号存在异常，请重新选择其他格口");
            CTxtHelp.AppendLog("[UI] " + lblTipMsg.getText());
            InitUsedableBox(true);
            return;
        }

        CTxtHelp.AppendLog("[UI] DeliverStep3,BoxID=" + property.BoxID);
        CLogicHandle.OpenBox(property, CBaseEnum.Lock_DispStoreOpen, CDataMgr.TDYPhone, CBaseEnum.Action_TDYCJ, "投递员存件开箱门");
    }
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBigBox;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnNormalBox;
    private javax.swing.JButton btnPreStep;
    private javax.swing.JButton btnSBigBox;
    private javax.swing.JButton btnSSmallBox;
    private javax.swing.JButton btnSmallBox;
    private javax.swing.JLabel lblBigBox;
    private javax.swing.JLabel lblDo;
    private javax.swing.JLabel lblNormalBox;
    private javax.swing.JLabel lblSBigBox;
    private javax.swing.JLabel lblSSmallBox;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblSmallBox;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlDo;
    private javax.swing.JPanel pnlTipMsg;
    // End of variables declaration//GEN-END:variables
}
