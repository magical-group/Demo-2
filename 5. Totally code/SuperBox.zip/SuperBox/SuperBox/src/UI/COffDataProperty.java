package UI;

public class COffDataProperty {
    public int ID = 0;
    public int Type = 0;
    public String Data = "";
}
