package UI;

import CustomControl.ITableButtenEvent;
import CustomControl.JTableButton;
import CustomControl.JTableData;
import DB.CDBHelper;
import DB.QueryEntity;
import FuncClass.CCommondFunc;
import FuncClass.CDataMgr;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import txt.CTxtHelp;

public class frmBoxError extends javax.swing.JPanel implements ITableButtenEvent {
    
    int columnIndex = 6;
    String[] columnNames = { "运单号", "格口1", "格口2", "关箱者", "时间", "备注", " " };
    final String m_strFileds = "fs_OrderID,fi_BoxID1,fi_BoxID2,fs_PID,substr(fs_Time1,6,11) as fs_Time1,fs_Note";
    final int PageSize = 8;
    int CurrentPageIndex = 1;
    int TotalPage = 0; 
    String m_strWhere = "";
    
    public frmBoxError() {
        initComponents();
        JTableData.initTable(tableData, 50);
    }

    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void VoiceTip() {
        CCommondFunc.VoiceTip("请选择需要取回的异常格口包裹");
    }

    public void TTkeyBoardInput(CBaseEnum.KeyType eKeyType, String strInput) {
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        switch (eKeyType) {
            case Key_ESC:
                CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Null, null);
                break;
        }
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        FuncClass.CBaseTime.StartTime(lblSeconds, 60);
        VoiceTip();
        if (CBaseEnum.RedirectType.Redirect_Pre != eRedirectType) lblTipMsg.setText("..."); 
        
        m_strWhere = "fi_DeviceID=" + CDataMgr.DeviceID + " and fi_State=0";
        switch (CDataMgr.LocalPwdType) {
            case 7:
                m_strWhere = m_strWhere + " and fs_PID='" + CDataMgr.TDYPhone + "' and fs_Pwd='" + CDataMgr.TDYPwd + "'";
                break;
            case 8:
                m_strWhere = m_strWhere + " and fs_PID='" + CDataMgr.UserPID + "' and fs_Pwd='" + CDataMgr.UserPwd + "'";
                break;
        }

        GetTotalPages();
        btnFirstPageActionPerformed(null);
    }
    
    public void ShowTipMsg(String content) {
        lblTipMsg.setText(content);
        CCommondFunc.VoiceTip(content);
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnExit = new javax.swing.JButton();
        lblTimeOut1 = new javax.swing.JLabel();
        lblSeconds = new javax.swing.JLabel();
        lblTimeOut2 = new javax.swing.JLabel();
        btnPreStep = new javax.swing.JButton();
        lblTitle = new javax.swing.JLabel();
        btnFirstPage = new javax.swing.JButton();
        btnPrevPage = new javax.swing.JButton();
        lbCurrentPage = new javax.swing.JLabel();
        lblSpace = new javax.swing.JLabel();
        lbTotalPage = new javax.swing.JLabel();
        btnNextPage = new javax.swing.JButton();
        btnLastPage = new javax.swing.JButton();
        pnlTipMsg = new javax.swing.JPanel();
        lblTipMsg = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableData = new javax.swing.JTable();

        setBackground(new java.awt.Color(6, 57, 104));
        setFont(new java.awt.Font("微软雅黑", 0, 15)); // NOI18N
        setPreferredSize(new java.awt.Dimension(1024, 768));

        btnExit.setBackground(new java.awt.Color(6, 57, 104));
        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnExit.png"))); // NOI18N
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblTimeOut1.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut1.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut1.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut1.setText("执行操作界面还剩");

        lblSeconds.setBackground(new java.awt.Color(6, 57, 104));
        lblSeconds.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblSeconds.setForeground(new java.awt.Color(255, 0, 0));
        lblSeconds.setText("60");

        lblTimeOut2.setBackground(new java.awt.Color(6, 57, 104));
        lblTimeOut2.setFont(new java.awt.Font("微软雅黑", 0, 18)); // NOI18N
        lblTimeOut2.setForeground(new java.awt.Color(255, 255, 255));
        lblTimeOut2.setText("秒，即将退出操作返回首页");

        btnPreStep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/btnBack.png"))); // NOI18N
        btnPreStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreStepActionPerformed(evt);
            }
        });

        lblTitle.setBackground(new java.awt.Color(6, 57, 104));
        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("异常格口取回");

        btnFirstPage.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnFirstPage.setText("首页");
        btnFirstPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstPageActionPerformed(evt);
            }
        });

        btnPrevPage.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnPrevPage.setText("上一页");
        btnPrevPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevPageActionPerformed(evt);
            }
        });

        lbCurrentPage.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lbCurrentPage.setForeground(new java.awt.Color(255, 255, 255));
        lbCurrentPage.setText("0");

        lblSpace.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lblSpace.setForeground(new java.awt.Color(255, 255, 255));
        lblSpace.setText("/");

        lbTotalPage.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        lbTotalPage.setForeground(new java.awt.Color(255, 255, 255));
        lbTotalPage.setText("0");

        btnNextPage.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnNextPage.setText("下一页");
        btnNextPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextPageActionPerformed(evt);
            }
        });

        btnLastPage.setFont(new java.awt.Font("微软雅黑", 1, 18)); // NOI18N
        btnLastPage.setLabel("末页");
        btnLastPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastPageActionPerformed(evt);
            }
        });

        lblTipMsg.setFont(new java.awt.Font("黑体", 0, 24)); // NOI18N
        lblTipMsg.setForeground(new java.awt.Color(255, 0, 0));
        lblTipMsg.setText("...");

        javax.swing.GroupLayout pnlTipMsgLayout = new javax.swing.GroupLayout(pnlTipMsg);
        pnlTipMsg.setLayout(pnlTipMsgLayout);
        pnlTipMsgLayout.setHorizontalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(lblTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 852, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlTipMsgLayout.setVerticalGroup(
            pnlTipMsgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTipMsgLayout.createSequentialGroup()
                .addComponent(lblTipMsg)
                .addGap(0, 10, Short.MAX_VALUE))
        );

        tableData.setFont(new java.awt.Font("微软雅黑", 0, 15)); // NOI18N
        tableData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableData.setPreferredSize(new java.awt.Dimension(1024, 64));
        jScrollPane2.setViewportView(tableData);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addComponent(lblTitle)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnFirstPage, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPrevPage, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(lbCurrentPage)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblSpace)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbTotalPage)
                        .addGap(34, 34, 34)
                        .addComponent(btnNextPage, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLastPage, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblTimeOut1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblSeconds)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTimeOut2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(171, Short.MAX_VALUE))
            .addComponent(pnlTipMsg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1032, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 474, Short.MAX_VALUE)
                .addComponent(pnlTipMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirstPage, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevPage, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNextPage, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLastPage, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbCurrentPage)
                    .addComponent(lblSpace)
                    .addComponent(lbTotalPage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPreStep, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTimeOut1)
                            .addComponent(lblSeconds)
                            .addComponent(lblTimeOut2))
                        .addGap(28, 28, 28))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(149, 149, 149)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 454, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(165, Short.MAX_VALUE)))
        );

        lblTitle.getAccessibleContext().setAccessibleName("异常格口取回");
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        TTkeyBoardInput(CBaseEnum.KeyType.Key_ESC, "");
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnPreStepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreStepActionPerformed
        
        switch (CDataMgr.LocalPwdType) {
            case 7: CDataMgr.MainHandle.OnEventShowForm(UI.CBaseEnum.FormCase.Form_DeliverSelect, CBaseEnum.RedirectType.Redirect_Pre, null); break;
            case 8: CDataMgr.MainHandle.OnEventShowForm(UI.CBaseEnum.FormCase.Form_UserPackageStep1, CBaseEnum.RedirectType.Redirect_Pre, null); break;
        }
    }//GEN-LAST:event_btnPreStepActionPerformed

    private void btnFirstPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstPageActionPerformed
        // 首页
        CurrentPageIndex = 1;
        GetCurrentRecords(CurrentPageIndex);
    }//GEN-LAST:event_btnFirstPageActionPerformed

    private void btnPrevPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevPageActionPerformed
        // 上一页
        if (this.CurrentPageIndex > 1) {
            CurrentPageIndex--;
            GetCurrentRecords(CurrentPageIndex);
        }
    }//GEN-LAST:event_btnPrevPageActionPerformed

    private void btnNextPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextPageActionPerformed
        // 下一页
        if (CurrentPageIndex < TotalPage) {
            CurrentPageIndex++;
            GetCurrentRecords(CurrentPageIndex);
        }
    }//GEN-LAST:event_btnNextPageActionPerformed

    private void btnLastPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastPageActionPerformed
        // 末页
        CurrentPageIndex = TotalPage;
        GetCurrentRecords(CurrentPageIndex);
    }//GEN-LAST:event_btnLastPageActionPerformed
    
    void JumpPwdInput(String gkbh) {
        String TriggerID = ""; String TriggerPwd = "";
        switch (CDataMgr.LocalPwdType) {
            case 7: TriggerID = CDataMgr.TDYPhone; TriggerPwd = CDataMgr.TDYPwd; break;
            case 8: TriggerID = CDataMgr.UserPID; TriggerPwd = CDataMgr.UserPwd; break;
        }
        
        CBoxProperty property = CCommondFunc.GetBox1(gkbh);
        if (CBaseEnum.BoxStatus.Box_Busy.ordinal() != property.BoxStatus) {
            CLogicHandle.OpenBox(property, CBaseEnum.Lock_ErrorOpen, TriggerID, 0, "异常格口开锁");
            BeginForm(CBaseEnum.RedirectType.Redirect_Pre, null);// 界面刷新
        }
        else {
            String err = "异常格口不允许开启，状态异常：" + property.BoxID;
            CTxtHelp.AppendLog("[Error] <JumpPwdInput> " + err);
            lblTipMsg.setText(err);
        }
    }
    
    // 计算页数
    void GetTotalPages() {
        int rowCount = 0;
        String strSql = "select count(fi_ID) as nCount from tb_BoxError where " + m_strWhere + " order by fi_ID desc";
        QueryEntity result = CDBHelper.getInstance().Query(strSql); // 查询数据
        if (!result.hasData) { CTxtHelp.AppendLog("[Error] <GetTotalPages> sql=" + strSql); return ;}
        
        ResultSet rs = result.dataRs;;
        try { if (rs.next()) { rowCount = CCommondFunc.GetIntDB(rs.getString("nCount")); } } 
        catch (SQLException e) { CTxtHelp.AppendLog("[Error]SQLException,errmsg:" + e.getMessage()); }
        finally { CDBHelper.getInstance().closeQuery(result); }
        
        TotalPage = rowCount / PageSize;
        if (rowCount % PageSize > 0) TotalPage += 1;//不足一個分頁行數的還是算一頁
        lbTotalPage.setText(String.valueOf(TotalPage));
    }
    
    private void GetCurrentRecords(int page) {
        FuncClass.CBaseTime.ReSetTime();// 重新计时
        
        JTableData.setData(tableData, null, columnNames, columnIndex, this);
        lbCurrentPage.setText(String.valueOf(CurrentPageIndex));
        
        String strSql = "";
        if (page == 1)
           strSql = "select " + m_strFileds + " from tb_BoxError where " + m_strWhere + " order by fi_ID desc limit 0, " + PageSize;
        else
        {
            int PreviousPageOffSet = (page - 1) * PageSize;
            strSql = "select " + m_strFileds + " from tb_BoxError where " + m_strWhere +
                    " and fi_ID not in (select fi_ID from tb_BoxError where " + m_strWhere + " order by fi_ID desc limit 0, " + PreviousPageOffSet + ")" +
                    " order by fi_ID desc limit 0, " + PageSize;
        }

        QueryEntity result = CDBHelper.getInstance().QueryWithCount(strSql);
        if (!result.hasData) { lbCurrentPage.setText("0"); return ; }
        
        lbCurrentPage.setText(String.valueOf(CurrentPageIndex));
        Object[][] rowData = JTableData.resultSetToObjectArray(result, "开箱");
        JTableData.setData(tableData, rowData, columnNames, columnIndex, this);
    
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnFirstPage;
    private javax.swing.JButton btnLastPage;
    private javax.swing.JButton btnNextPage;
    private javax.swing.JButton btnPreStep;
    private javax.swing.JButton btnPrevPage;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbCurrentPage;
    private javax.swing.JLabel lbTotalPage;
    private javax.swing.JLabel lblSeconds;
    private javax.swing.JLabel lblSpace;
    private javax.swing.JLabel lblTimeOut1;
    private javax.swing.JLabel lblTimeOut2;
    private javax.swing.JLabel lblTipMsg;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlTipMsg;
    private javax.swing.JTable tableData;
    // End of variables declaration//GEN-END:variables

    @Override
    public void invoke(ActionEvent e) {
        JTableButton button = (JTableButton)e.getSource();
        int row = button.getRow();
        String gkbh = String.valueOf(tableData.getValueAt(row, 2)); 
        JumpPwdInput(gkbh);
    }
}
