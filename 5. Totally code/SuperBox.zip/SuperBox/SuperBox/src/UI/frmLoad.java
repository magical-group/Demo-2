package UI;

import DB.CDBHelper;
import FuncClass.CDataMgr;
import HLDClient.CSocketMgr;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import txt.CTxtHelp;

public class frmLoad extends javax.swing.JPanel {
    int m_iStep = 1;
    String m_stTitle = "程序启动...";
    boolean m_bLoadEnd = true;
    
    public frmLoad() {
        initComponents();
    }
    
    class RunTimeThread implements Runnable {
        @Override
        public void run() {
            while (!m_bLoadEnd) {
                StepProcess();
                
                try { Thread.sleep(1000); }  catch (InterruptedException e)  {}
            }
        }
    }
    
    @Override
    public void paintComponent(Graphics g){
        ImageIcon icon = new ImageIcon(getClass().getResource(CDataMgr.BackImg));
        g.drawImage(icon.getImage(), 0, 0, getSize().width, getSize().height, this);
    }
    
    void StepShow(String title) {
        lblTitle.setText(title);
        if (m_iStep != 100) CTxtHelp.AppendLog("[Info] " + title);
    }
    
    void StepProcess() {
        //CDataMgr.MainHandle.setAlwaysOnTop(true);// 窗体置前
        String err = "";
        
        if (m_iStep != -1) StepShow(m_iStep + "." + m_stTitle);
        
        switch (m_iStep) {
            case 1:
                //CDataMgr.MainHandle.SetCursorShow(false);
                jProgressBar1.setValue(10);
                m_iStep = 2; m_stTitle = "加载配置文件 AppConfig.txt...";
                if (UI.CBaseEnum.SystemType.WINDOW == CDataMgr.ESystemType) FuncClass.TtsHelper.getInstance().speak("");
                break;
            case 2:
                jProgressBar1.setValue(20);
                err = CSystemDAO.getInstance().LoadINI();
                if (!"".equals(err)) { m_iStep = -1; StepShow(err); } else { m_iStep = 3; m_stTitle = "加载数据库文件 Data.db3...";}
                break;
            case 3: 
                jProgressBar1.setValue(30);
                err = CDBHelper.getInstance().Init();
                if (!"".equals(err)) { m_iStep = -1; StepShow(err); } else { m_iStep = 4; m_stTitle = "日志清理...";}
                break;
             case 4:
                jProgressBar1.setValue(40);
                CSystemDAO.getInstance().ClearLog();
                m_iStep = 5; m_stTitle = "正在初始化串口通信(主板)...";
                CSystemDAO.getInstance().StartThread_Run();
                CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "程序加载,"+ CSystemDAO.getInstance().GetSystemStartTime());
                m_iStep = 8;
                break;    
            case 5:
                jProgressBar1.setValue(50);  
                err = CSystemDAO.getInstance().LoadCOM_Device();
                if (!"".equals(err)) { 
                    m_iStep = -1; StepShow(err); 
                    CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_HardWare, err);
                } else { m_iStep = 6; m_stTitle = "正在初始化串口通信(金属键盘)..."; }
                break;
            case 6:
                jProgressBar1.setValue(60);
                err = CSystemDAO.getInstance().LoadCOM_Key();// m_iStep = -1; 金属键盘加载失败只做提示
                if (!"".equals(err)) { 
                    StepShow(err); 
                    CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_HardWare, err);
                } 
                m_iStep = 7; m_stTitle = "正在更新箱柜状态...";
                break;
            case 7:
                jProgressBar1.setValue(70);
                err = CSystemDAO.getInstance().UpdateBoxFromRelay();
                if (!"".equals(err)) { 
                    m_iStep = -1; StepShow(err); 
                    CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Error_HardWare, err);
                } 
                else 
                { 
                    CSystemDAO.getInstance().ReadPower();
                    HLDBoard.CHardwareMonitor.getInstance().StartCheck();
                    m_iStep = 8; m_stTitle = "正在连接服务器..."; 
                }
                break;
            case 8:
                // 系统加载完毕(跳转到Standby界面)
                // 加载通讯
                m_iStep = 100;
                jProgressBar1.setValue(100);
                StepShow("加载结束");
                switch (CDataMgr.ESystemType) {
                    case WINDOW:
                        CDataMgr.SoftType = "WINDOW_V";
                        break;
                    case LINUX:
                        CDataMgr.SoftType = "LINUX_V";
                        break;
                }
                CDataMgr.MainHandle.OnEventShowForm(CBaseEnum.FormCase.Form_StandBy, CBaseEnum.RedirectType.Redirect_Next, null);
                CSocketMgr.getInstance().Start();
                CSystemDAO.getInstance().AddWebLog(CBaseEnum.SystemLog_Normal, "程序运行");
                // 同步更新版本号
                func.CCommondFunc.AddRest_Execute("update tb_Device set fs_Version='" + CDataMgr.SoftVerSion + "',fi_Company='" + CSystemDAO.getInstance().Company + "' where fi_DeviceID=" + CDataMgr.DeviceID);
                break;
            case 100:
                m_bLoadEnd = true;
                break;
        }
    }
    
    public void BeginForm(CBaseEnum.RedirectType eRedirectType, Object oParam) {
        m_bLoadEnd = false;
        (new Thread(new RunTimeThread())).start();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();

        setBackground(new java.awt.Color(6, 57, 104));

        lblTitle.setFont(new java.awt.Font("微软雅黑", 0, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setText("1.程序启动...");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(199, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jProgressBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 697, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(128, 128, 128))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(289, 289, 289)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(385, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JLabel lblTitle;
    // End of variables declaration//GEN-END:variables
}
