package FuncClass;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class TtsHelper{

    private static class TtsHelperStoreHolder {
        private static final TtsHelper instance = new TtsHelper();
    }
    
    public static TtsHelper getInstance() {
        return TtsHelperStoreHolder.instance;
    }
    
    ActiveXComponent sap = null;
    ActiveXComponent voice = null;
    
    TtsHelper(){
        // InitVoice
        try {
            sap = new ActiveXComponent("Sapi.SpVoice");
            Variant allVoices = Dispatch.call(sap, "GetVoices");
            Dispatch dispVoices = allVoices.toDispatch();
            ActiveXComponent o = new ActiveXComponent(dispVoices);
            int count = o.getPropertyAsInt("Count");

            for (int i = 0; i < count; i++){
                Dispatch voicePatch = Dispatch.call(o, "Item", i).toDispatch();
                voice = new ActiveXComponent(voicePatch);
                String name = voice.invoke("GetDescription").getString().toLowerCase();
                if (name.contains("chinese")) {
                    Dispatch.putRef(sap, "Voice", voice);
                    break;
                }
                else {
                    voice = null;
                }
            }
        }
        catch (Exception ex) {
            voice = null;
            txt.CTxtHelp.AppendLog("[Error] <TtsHelper>:" + ex.getMessage());
        }
    }

    public void speak(String msg) {
        if (null == voice) return;
        
        try {
            Object[] params = new Object[2];
            params[0] = msg;
            params[1] = TtsHelper.SpeechVoiceSpeakFlags.SVSFlagsAsync;
            Dispatch.call(sap, "Speak", params);
        }
        catch (Exception ex) {
            txt.CTxtHelp.AppendLog("[Error] <speak>:" + ex.getMessage());
        }
    }

    public void Stop() {
        if (null == voice) return;
        
        try {
            Object[] params = new Object[2];
            params[0] = "";
            params[1] = TtsHelper.SpeechVoiceSpeakFlags.SVSFPurgeBeforeSpeak;
            Dispatch.call(sap, "Speak", params);
        }
        catch (Exception ex) {
            txt.CTxtHelp.AppendLog("[Error] <Stop>:" + ex.getMessage());
        }
    }
    
    public void release(){
        try {
            sap.safeRelease();
        }
        catch (Exception ex) {
            txt.CTxtHelp.AppendLog("[Error] <release>:" + ex.getMessage());
        }
    }

    class SpeechVoiceSpeakFlags{
        public final static int SVSFUnusedFlags = -128;
        public final static int SVSFDefault = 0;
        public final static int SVSFlagsAsync = 1;
        public final static int SVSFPurgeBeforeSpeak = 2;
        public final static int SVSFIsFilename = 4;
        public final static int SVSFIsXML = 8;
        public final static int SVSFIsNotXML = 16;
        public final static int SVSFPersistXML = 32;
        public final static int SVSFNLPMask = 64;
        public final static int SVSFNLPSpeakPunc = 64;
        public final static int SVSFVoiceMask = 127;
    }
}
