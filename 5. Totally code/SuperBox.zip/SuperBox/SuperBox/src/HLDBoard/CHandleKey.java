package HLDBoard;

import FuncClass.CDataMgr;
import UI.CBaseEnum;
import static UI.CBaseEnum.KeyType.Key_DOWN;
import static UI.CBaseEnum.KeyType.Key_ENTER;
import static UI.CBaseEnum.KeyType.Key_ESC;
import static UI.CBaseEnum.KeyType.Key_NUMBER;
import static UI.CBaseEnum.KeyType.Key_PERIOD;
import static UI.CBaseEnum.KeyType.Key_SPACE;
import static UI.CBaseEnum.KeyType.Key_UP;

public class CHandleKey {
    
    public static void Execute(byte val) {
        CBaseEnum.KeyType eKeyType = Key_NUMBER;
        String strValue = "";
    
        if (0 != val) {
            switch (val) {
                case 48: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_0; break;
                case 49: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_1; break;
                case 50: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_2; break;
                case 51: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_3; break;
                case 52: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_4; break;
                case 53: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_5; break;
                case 54: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_6; break;
                case 55: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_7; break;
                case 56: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_8; break;
                case 57: eKeyType = Key_NUMBER; strValue = CBaseEnum.PIN_PRESSED_VK_9; break;
                case 8:  eKeyType = Key_SPACE; strValue = CBaseEnum.PIN_PRESSED_SPACE; break;
                case 46: eKeyType = Key_PERIOD; strValue = CBaseEnum.PIN_PRESSED_PERIOD; break;
                case 27: eKeyType = Key_ESC; strValue = CBaseEnum.PIN_PRESSED_ESC; break;
                case 33: eKeyType = Key_UP; strValue = CBaseEnum.PIN_PRESSED_UP; break;
                case 34: eKeyType = Key_DOWN; strValue = CBaseEnum.PIN_PRESSED_DOWN; break;
                case 13: eKeyType = Key_ENTER; strValue = CBaseEnum.PIN_PRESSED_ENTER; break;
            }

            CDataMgr.MainHandle.OnTTKeyBoardInput(eKeyType, strValue);
        }
    }
}
