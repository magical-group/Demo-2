package CustomControl;
 
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
 
public class JTableButtonEditor extends DefaultCellEditor
{
    private JTableButton button;
    private ITableButtenEvent event;
 
    public JTableButtonEditor()
    {
        super(new JTextField());
        this.setClickCountToStart(1);// 设置点击几次激活编辑
        this.button = new JTableButton("");
        this.button.setBounds(0, 0, 100, 50);// 设置按钮的大小及位置
        this.button.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                JTableButtonEditor.this.fireEditingCanceled();
                event.invoke(e);
            }
        });
    }

    public JTableButtonEditor(ITableButtenEvent e) {
        this();
        this.event = e;
    }
 
    @Override
    public Object getCellEditorValue()
    {
        return this.button.getText();
    }
    
    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
    {
        button.setText(value == null ? "" : String.valueOf(value));
        button.setRow(row);
        button.setColumn(column);
        return button;
    }
}
