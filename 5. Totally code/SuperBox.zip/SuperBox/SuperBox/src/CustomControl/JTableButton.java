package CustomControl;

import javax.swing.JButton;

public class JTableButton extends JButton{

    private int row;
    private int column;
    
    public JTableButton() {

    }

    public JTableButton(String name) {
        super(name);
    }
    
    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }
}
