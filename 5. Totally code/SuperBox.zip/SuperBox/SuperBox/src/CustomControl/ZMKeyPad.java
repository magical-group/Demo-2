package CustomControl;

import FuncClass.CDataMgr;
import SMDataProcess.CDataMgrSM;
import UI.CBaseEnum;
import static UI.CBaseEnum.KeyType.Key_ENTER;
import static UI.CBaseEnum.KeyType.Key_NUMBER;
import static UI.CBaseEnum.KeyType.Key_SPACE;

public class ZMKeyPad extends javax.swing.JPanel {

    public ZMKeyPad() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnNum2 = new javax.swing.JButton();
        btnNum1 = new javax.swing.JButton();
        btnNum3 = new javax.swing.JButton();
        btnNum4 = new javax.swing.JButton();
        btnNum5 = new javax.swing.JButton();
        btnNum6 = new javax.swing.JButton();
        btnNum7 = new javax.swing.JButton();
        btnNum8 = new javax.swing.JButton();
        btnNum9 = new javax.swing.JButton();
        btnSpace = new javax.swing.JButton();
        btnNum0 = new javax.swing.JButton();
        btnChrQ = new javax.swing.JButton();
        btnChrW = new javax.swing.JButton();
        btnChrE = new javax.swing.JButton();
        btnChrR = new javax.swing.JButton();
        btnChrT = new javax.swing.JButton();
        btnChrY = new javax.swing.JButton();
        btnChrU = new javax.swing.JButton();
        btnChrI = new javax.swing.JButton();
        btnChrO = new javax.swing.JButton();
        btnChrP = new javax.swing.JButton();
        btnChrA = new javax.swing.JButton();
        btnChrS = new javax.swing.JButton();
        btnChrD = new javax.swing.JButton();
        btnChrF = new javax.swing.JButton();
        btnChrG = new javax.swing.JButton();
        btnChrH = new javax.swing.JButton();
        btnChrJ = new javax.swing.JButton();
        btnChrK = new javax.swing.JButton();
        btnChrL = new javax.swing.JButton();
        btnChrZ = new javax.swing.JButton();
        btnChrX = new javax.swing.JButton();
        btnChrC = new javax.swing.JButton();
        btnChrV = new javax.swing.JButton();
        btnChrB = new javax.swing.JButton();
        btnChrN = new javax.swing.JButton();
        btnChrM = new javax.swing.JButton();
        btnChrItems = new javax.swing.JButton();
        btnChrEnter = new javax.swing.JButton();

        setBackground(new java.awt.Color(18, 89, 145));

        btnNum2.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum2.setText("2");
        btnNum2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum2ActionPerformed(evt);
            }
        });

        btnNum1.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum1.setText("1");
        btnNum1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum1ActionPerformed(evt);
            }
        });

        btnNum3.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum3.setText("3");
        btnNum3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum3ActionPerformed(evt);
            }
        });

        btnNum4.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum4.setText("4");
        btnNum4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum4ActionPerformed(evt);
            }
        });

        btnNum5.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum5.setText("5");
        btnNum5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum5ActionPerformed(evt);
            }
        });

        btnNum6.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum6.setText("6");
        btnNum6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum6ActionPerformed(evt);
            }
        });

        btnNum7.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum7.setText("7");
        btnNum7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum7ActionPerformed(evt);
            }
        });

        btnNum8.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum8.setText("8");
        btnNum8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum8ActionPerformed(evt);
            }
        });

        btnNum9.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum9.setText("9");
        btnNum9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum9ActionPerformed(evt);
            }
        });

        btnSpace.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnSpace.setText("删除");
        btnSpace.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSpaceActionPerformed(evt);
            }
        });

        btnNum0.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnNum0.setText("0");
        btnNum0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNum0ActionPerformed(evt);
            }
        });

        btnChrQ.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrQ.setText("Q");
        btnChrQ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrQActionPerformed(evt);
            }
        });

        btnChrW.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrW.setText("W");
        btnChrW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrWActionPerformed(evt);
            }
        });

        btnChrE.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrE.setText("E");
        btnChrE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrEActionPerformed(evt);
            }
        });

        btnChrR.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrR.setText("R");
        btnChrR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrRActionPerformed(evt);
            }
        });

        btnChrT.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrT.setText("T");
        btnChrT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrTActionPerformed(evt);
            }
        });

        btnChrY.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrY.setText("Y");
        btnChrY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrYActionPerformed(evt);
            }
        });

        btnChrU.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrU.setText("U");
        btnChrU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrUActionPerformed(evt);
            }
        });

        btnChrI.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrI.setText("I");
        btnChrI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrIActionPerformed(evt);
            }
        });

        btnChrO.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrO.setText("O");
        btnChrO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrOActionPerformed(evt);
            }
        });

        btnChrP.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrP.setText("P");
        btnChrP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrPActionPerformed(evt);
            }
        });

        btnChrA.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrA.setText("A");
        btnChrA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrAActionPerformed(evt);
            }
        });

        btnChrS.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrS.setText("S");
        btnChrS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrSActionPerformed(evt);
            }
        });

        btnChrD.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrD.setText("D");
        btnChrD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrDActionPerformed(evt);
            }
        });

        btnChrF.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrF.setText("F");
        btnChrF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrFActionPerformed(evt);
            }
        });

        btnChrG.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrG.setText("G");
        btnChrG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrGActionPerformed(evt);
            }
        });

        btnChrH.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrH.setText("H");
        btnChrH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrHActionPerformed(evt);
            }
        });

        btnChrJ.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrJ.setText("J");
        btnChrJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrJActionPerformed(evt);
            }
        });

        btnChrK.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrK.setText("K");
        btnChrK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrKActionPerformed(evt);
            }
        });

        btnChrL.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrL.setText("L");
        btnChrL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrLActionPerformed(evt);
            }
        });

        btnChrZ.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrZ.setText("Z");
        btnChrZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrZActionPerformed(evt);
            }
        });

        btnChrX.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrX.setText("X");
        btnChrX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrXActionPerformed(evt);
            }
        });

        btnChrC.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrC.setText("C");
        btnChrC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrCActionPerformed(evt);
            }
        });

        btnChrV.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrV.setText("V");
        btnChrV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrVActionPerformed(evt);
            }
        });

        btnChrB.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrB.setText("B");
        btnChrB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrBActionPerformed(evt);
            }
        });

        btnChrN.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrN.setText("N");
        btnChrN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrNActionPerformed(evt);
            }
        });

        btnChrM.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrM.setText("M");
        btnChrM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrMActionPerformed(evt);
            }
        });

        btnChrItems.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrItems.setText("符号");
        btnChrItems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrItemsActionPerformed(evt);
            }
        });

        btnChrEnter.setFont(new java.awt.Font("微软雅黑", 0, 24)); // NOI18N
        btnChrEnter.setText("确定");
        btnChrEnter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChrEnterActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(btnChrQ, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrW, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrE, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrR, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrT, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrY, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrU, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrI, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrO, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrP, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(btnChrA, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrS, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrD, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrF, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrG, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrH, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrJ, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrK, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChrL, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(144, 144, 144)
                            .addComponent(btnChrZ, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrX, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrC, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrV, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrB, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrN, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrM, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnChrItems, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnChrEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(16, 16, 16)
                            .addComponent(btnNum1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum7, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum8, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum9, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnNum0, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnSpace, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNum2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSpace, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNum0, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnChrQ, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrW, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrE, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrR, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrT, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrY, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrU, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrI, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrO, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrP, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnChrA, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrS, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrD, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrF, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrG, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrH, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrJ, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrK, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnChrL, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnChrM, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrItems, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnChrB, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrN, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnChrC, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrV, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnChrZ, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnChrX, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnNum1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum1ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_1);
    }//GEN-LAST:event_btnNum1ActionPerformed

    private void btnNum2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum2ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_2);
    }//GEN-LAST:event_btnNum2ActionPerformed

    private void btnNum3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum3ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_3);
    }//GEN-LAST:event_btnNum3ActionPerformed

    private void btnNum4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum4ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_4);
    }//GEN-LAST:event_btnNum4ActionPerformed

    private void btnNum5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum5ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_5);
    }//GEN-LAST:event_btnNum5ActionPerformed

    private void btnNum6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum6ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_6);
    }//GEN-LAST:event_btnNum6ActionPerformed

    private void btnNum7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum7ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_7);
    }//GEN-LAST:event_btnNum7ActionPerformed

    private void btnNum8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum8ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_8);
    }//GEN-LAST:event_btnNum8ActionPerformed

    private void btnNum9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum9ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_9);
    }//GEN-LAST:event_btnNum9ActionPerformed

    private void btnNum0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNum0ActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, CBaseEnum.PIN_PRESSED_VK_0);
    }//GEN-LAST:event_btnNum0ActionPerformed

    private void btnChrQActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrQActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "Q");
    }//GEN-LAST:event_btnChrQActionPerformed

    private void btnChrWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrWActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "W");
    }//GEN-LAST:event_btnChrWActionPerformed

    private void btnChrEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrEActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER, "E");
    }//GEN-LAST:event_btnChrEActionPerformed

    private void btnChrRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrRActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "R");
    }//GEN-LAST:event_btnChrRActionPerformed

    private void btnChrTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrTActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "T");
    }//GEN-LAST:event_btnChrTActionPerformed

    private void btnChrYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrYActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "Y");
    }//GEN-LAST:event_btnChrYActionPerformed

    private void btnChrUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrUActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "U");
    }//GEN-LAST:event_btnChrUActionPerformed

    private void btnChrIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrIActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "I");
    }//GEN-LAST:event_btnChrIActionPerformed

    private void btnChrOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrOActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "O");
    }//GEN-LAST:event_btnChrOActionPerformed

    private void btnChrPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrPActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "P");
    }//GEN-LAST:event_btnChrPActionPerformed

    private void btnChrAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrAActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "A");
    }//GEN-LAST:event_btnChrAActionPerformed

    private void btnChrSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrSActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "S");
    }//GEN-LAST:event_btnChrSActionPerformed

    private void btnChrDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrDActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "D");
    }//GEN-LAST:event_btnChrDActionPerformed

    private void btnChrFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrFActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "F");
    }//GEN-LAST:event_btnChrFActionPerformed

    private void btnChrGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrGActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "G");
    }//GEN-LAST:event_btnChrGActionPerformed

    private void btnChrHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrHActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "H");
    }//GEN-LAST:event_btnChrHActionPerformed

    private void btnChrJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrJActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "J");
    }//GEN-LAST:event_btnChrJActionPerformed

    private void btnChrKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrKActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "K");
    }//GEN-LAST:event_btnChrKActionPerformed

    private void btnChrLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrLActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "L");
    }//GEN-LAST:event_btnChrLActionPerformed

    private void btnChrZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrZActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "Z");
    }//GEN-LAST:event_btnChrZActionPerformed

    private void btnChrXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrXActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "X");
    }//GEN-LAST:event_btnChrXActionPerformed

    private void btnChrCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrCActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "C");
    }//GEN-LAST:event_btnChrCActionPerformed

    private void btnChrVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrVActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "V");
    }//GEN-LAST:event_btnChrVActionPerformed

    private void btnChrBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrBActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "B");
    }//GEN-LAST:event_btnChrBActionPerformed

    private void btnChrNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrNActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "N");
    }//GEN-LAST:event_btnChrNActionPerformed

    private void btnChrMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrMActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_NUMBER,  "M");
    }//GEN-LAST:event_btnChrMActionPerformed

    private void btnSpaceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSpaceActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_SPACE, CBaseEnum.PIN_PRESSED_SPACE);
    }//GEN-LAST:event_btnSpaceActionPerformed

    private void btnChrEnterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrEnterActionPerformed
        CDataMgr.MainHandle.OnTTKeyBoardInput(Key_ENTER, CBaseEnum.PIN_PRESSED_ENTER);
    }//GEN-LAST:event_btnChrEnterActionPerformed

    private void btnChrItemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChrItemsActionPerformed
        // 符号
        FuncClass.CDataMgr.AllKeyPadHandle.OnEventShowForm(CBaseEnum.FormCase.Form_ZFKeyPad);
    }//GEN-LAST:event_btnChrItemsActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChrA;
    private javax.swing.JButton btnChrB;
    private javax.swing.JButton btnChrC;
    private javax.swing.JButton btnChrD;
    private javax.swing.JButton btnChrE;
    private javax.swing.JButton btnChrEnter;
    private javax.swing.JButton btnChrF;
    private javax.swing.JButton btnChrG;
    private javax.swing.JButton btnChrH;
    private javax.swing.JButton btnChrI;
    private javax.swing.JButton btnChrItems;
    private javax.swing.JButton btnChrJ;
    private javax.swing.JButton btnChrK;
    private javax.swing.JButton btnChrL;
    private javax.swing.JButton btnChrM;
    private javax.swing.JButton btnChrN;
    private javax.swing.JButton btnChrO;
    private javax.swing.JButton btnChrP;
    private javax.swing.JButton btnChrQ;
    private javax.swing.JButton btnChrR;
    private javax.swing.JButton btnChrS;
    private javax.swing.JButton btnChrT;
    private javax.swing.JButton btnChrU;
    private javax.swing.JButton btnChrV;
    private javax.swing.JButton btnChrW;
    private javax.swing.JButton btnChrX;
    private javax.swing.JButton btnChrY;
    private javax.swing.JButton btnChrZ;
    private javax.swing.JButton btnNum0;
    private javax.swing.JButton btnNum1;
    private javax.swing.JButton btnNum2;
    private javax.swing.JButton btnNum3;
    private javax.swing.JButton btnNum4;
    private javax.swing.JButton btnNum5;
    private javax.swing.JButton btnNum6;
    private javax.swing.JButton btnNum7;
    private javax.swing.JButton btnNum8;
    private javax.swing.JButton btnNum9;
    private javax.swing.JButton btnSpace;
    // End of variables declaration//GEN-END:variables
}
