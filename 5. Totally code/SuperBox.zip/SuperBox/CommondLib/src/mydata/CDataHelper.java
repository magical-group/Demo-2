package mydata;

import java.io.UnsupportedEncodingException;
import txt.CTxtHelp;

public class CDataHelper {
    
    private static class DataHelperHolder {
        private static final CDataHelper instance = new CDataHelper();
    }
    
    public static CDataHelper getInstance() {
        return DataHelperHolder.instance;
    }
    
    public int bytesToInt(byte[] bb, int position) {  
        if (bb.length < 4) return 0;
        
        int number = bb[position] & 0xFF;  
        number |= ((bb[position + 1] << 8) & 0xFF00);  
        number |= ((bb[position + 2] << 16) & 0xFF0000);  
        number |= ((bb[position + 3] << 24) & 0xFF000000);
        
        return number;
    }
    
    public long byteToLong(byte[] bb, int position) { 
        if (bb.length < 8) return 0;
        
        long s = 0;  
        long s0 = bb[position] & 0xff;// 最低位  
        long s1 = bb[position + 1] & 0xff;  
        long s2 = bb[position + 2] & 0xff;  
        long s3 = bb[position + 3] & 0xff;  
        long s4 = bb[position + 4] & 0xff;// 最低位  
        long s5 = bb[position + 5] & 0xff;  
        long s6 = bb[position + 6] & 0xff;  
        long s7 = bb[position + 7] & 0xff; // s0不变  
        s1 <<= 8;  
        s2 <<= 16;  
        s3 <<= 24;  
        s4 <<= 8 * 4;  
        s5 <<= 8 * 5;  
        s6 <<= 8 * 6;  
        s7 <<= 8 * 7;  
        s = s0 | s1 | s2 | s3 | s4 | s5 | s6 | s7;  
        
        return s;  
    } 
    
    public void intToByte(byte[] bb, int position, int number) {
        bb[position] = (byte)(0xff & number);  
        bb[position + 1] = (byte)((0xff00 & number) >> 8);  
        bb[position + 2] = (byte)((0xff0000 & number) >> 16);  
        bb[position + 3] = (byte)((0xff000000 & number) >> 24);
    }
    
    public void longToByte(byte[] bb, int position, long number) {
        for (int i = 0; i < 8; i++) {  
            bb[position++] = new Long(number & 0xff).byteValue();  
            number = number >> 8;   // 将最低位保存在最低位  
        }  
    }  
    
    public static byte[] StringToByte(String str) {
        try {
            return str.getBytes("GB2312");// gb2312
        } catch (UnsupportedEncodingException ex) { }
        
        return null;
    }
    public static int String2Int(String str) {
         try {
            return Integer.parseInt(str);
        } catch (Exception ex) { }
        
        return 0;
    }
    public static String ArrayByteToString(byte[] bytes) {
        try { return new String(bytes, "GB2312"); } catch (UnsupportedEncodingException ex) { CTxtHelp.AppendLog("[Error] [CCommondFunc]<ArrayByteToString>:" + ex.getMessage()); }
        return "";
    }
}
