package rest;

public class PostResult {
    public boolean IsSuccess = false;
    public int Code = 0;
    public String Info = "";
    public String ErrMsg = "";
    
    public static int NETERROR = -1;
}
