package rest;

import encryption.SecurityHelper;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class CRestHelper {

    static PostResult HttpPost(String strUrl, String strcontent) {
        
    	PostResult ret = new PostResult();
    	
    	String jsonBack = "";
        
        try {
            URL url = new URL(strUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setRequestMethod("POST");
            connection.setUseCaches(false);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            connection.connect();

            OutputStream os = connection.getOutputStream(); 
            os.write(strcontent.getBytes("UTF-8")); 
            os.close(); 

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                jsonBack += line;
            }

            jsonBack = jsonBack.replaceAll("\\\\","");
            jsonBack = jsonBack.substring(1, jsonBack.length() - 1);
            JSONObject jsonInfo = JSONObject.fromObject(jsonBack);
            if (jsonInfo.containsKey("code")) 
            {
                ret.Code = (Integer) jsonInfo.get("code");
                ret.Info = (String) jsonInfo.get("info");
                ret.Info = SecurityHelper.DecryptDES(SecurityHelper.key, ret.Info);
                ret.ErrMsg = (String) jsonInfo.get("errmsg");
                if (1 == ret.Code) ret.IsSuccess = true;
            }
        }
        catch (IOException ex) {
            ret.Code = PostResult.NETERROR;
            ret.ErrMsg = ex.getMessage();
            System.out.println("IOException:" + ret.ErrMsg);
        } 
        return ret;
    }
    
    public static JSONArray GetDataTable(String url, String data)
    {
        JSONArray ret = null;
        data = SecurityHelper.EncryptDES(SecurityHelper.key, data);
    	String strJson = "{\"data\":\"" + data + "\"}";
        PostResult entity = HttpPost(url, strJson);
        if (PostResult.NETERROR != entity.Code) {
            ret = JSONArray.fromObject(entity.Info);
        }
        return ret;
    }
    
    public static int ExecuteNonQuery(String url, String data)
    {
        data = SecurityHelper.EncryptDES(SecurityHelper.key, data);
    	String strJson = "{\"data\":\"" + data + "\"}";
        PostResult entity = HttpPost(url, strJson);
        return entity.Code;
    }
    
    public static PostResult Process(String url, String data)
    {
        data = SecurityHelper.EncryptDES(SecurityHelper.key, data);
    	String strJson = "{\"data\":\"" + data + "\"}";
        return HttpPost(url, strJson);
    }
}
