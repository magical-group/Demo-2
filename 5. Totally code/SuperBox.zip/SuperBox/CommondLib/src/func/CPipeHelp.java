package func;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import txt.CTxtHelp;

public class CPipeHelp {
    static String filePath = System.getProperty("user.dir") + File.separator + "soft" + File.separator + "pipe";
    public static int outTime = 30;// 超时设置(秒)
    
    public static long Now() {
        return System.currentTimeMillis() / 1000;
    }
    
    public static long Read() {
        long timestamp = 0;
        InputStreamReader read = null;
        BufferedReader br = null;
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                try { file.createNewFile(); }  catch (IOException e) { } 
            }
            else {
                read = new InputStreamReader(new FileInputStream(file)); 
                br = new BufferedReader(read);
                String lineTxt = br.readLine(); 
                if (null != lineTxt) timestamp = Long.valueOf(lineTxt);
            }
        } catch (Exception ex) {
            CTxtHelp.AppendLog("[Error] CPipeHelp_Read,errmsg1:" + ex.getMessage());
        }
        finally {
            try { if (null != br) br.close(); } catch (IOException ex) { CTxtHelp.AppendLog("[Error] CPipeHelp_Read,errmsg2:" + ex.getMessage()); }
            try { if (null != read) read.close(); } catch (IOException ex) { CTxtHelp.AppendLog("[Error] CPipeHelp_Read,errmsg3:" + ex.getMessage()); }
        }
        return timestamp;
    }
    
    public static boolean Write() {
        boolean ret = false;
        long timestamp = System.currentTimeMillis() / 1000;  
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            File file = new File(filePath);
            if (!file.exists()) try { file.createNewFile(); }  catch (IOException e) { } 
            fw = new FileWriter(file.getAbsoluteFile(), false);
            bw = new BufferedWriter(fw);
            bw.write(String.valueOf(timestamp));
            ret = true;
        } catch (IOException ex) {
            CTxtHelp.AppendLog("[Error] CPipeHelp_Write,errmsg1:" + ex.getMessage());
        } finally {
            try { if (null != bw) bw.close(); } catch (IOException ex) { CTxtHelp.AppendLog("[Error] CPipeHelp_Write,errmsg2:" + ex.getMessage()); }
            try { if (null != fw) fw.close(); } catch (IOException ex) { CTxtHelp.AppendLog("[Error] CPipeHelp_Write,errmsg3:" + ex.getMessage()); }
        }
        return ret;
    }
}
