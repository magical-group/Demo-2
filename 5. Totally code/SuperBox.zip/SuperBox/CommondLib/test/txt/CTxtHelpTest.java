/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package txt;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class CTxtHelpTest {
    
    public CTxtHelpTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of AppendLog method, of class CTxtHelp.
     */
    @Test
    public void testAppendLog() {
        System.out.println("AppendLog");
        String newStr = "testAppendLog";
        boolean ret = CTxtHelp.AppendLog(newStr);
        System.out.println("testAppendLog," + (ret ? "ok" : "error"));
    }

    /**
     * Test of GetLogPath method, of class CTxtHelp.
     */
    @Test
    public void testGetLogPath() {
        System.out.println("GetLogPath");
        String result = CTxtHelp.GetLogPath();
        System.out.println("testGetLogPath,ok,path=" + result);
    }

    /**
     * Test of creatTxtFile method, of class CTxtHelp.
     */
    @Test
    public void testCreatTxtFile() {
        System.out.println("creatTxtFile");
        String strDir = "D:\\";
        String filePath = "D:\\test1.txt";
        boolean result = CTxtHelp.creatTxtFile(strDir, filePath);
        System.out.println("testCreatTxtFile," + (result ? "ok" : "error"));
    }

    /**
     * Test of writeTxtFile method, of class CTxtHelp.
     */
    @Test
    public void testWriteTxtFile() {
        System.out.println("writeTxtFile");
        String strDir = "D:\\";
        String filePath = "D:\\test.txt";
        String newStr = "333";
        boolean addtime = false;
        boolean newline = false;
        boolean result = CTxtHelp.writeTxtFile(strDir, filePath, newStr, addtime, newline);
        System.out.println("testWriteTxtFile," + (result ? "ok" : "error"));
    }
}
