package SMDataProcess;

import SMProtocol.CSPDAO;

public class KeySerialPort {
    static CSPDAO m_spDao;
    static CKeyDAO m_keyDao;
    static volatile boolean m_bConnection = false;
    
    // 打开串口
    public boolean OpenSerialPort(String strPortName, int iBaudRate, StringBuffer strMsg) {		
        m_spDao = new CSPDAO(new CProtocolHandle2());
        m_keyDao = new CKeyDAO(m_spDao);
        boolean ret = m_spDao.BeginWork(strPortName, iBaudRate, 0, 8, 1, strMsg);
        if (ret) {
            ret = m_keyDao.LoadKeyBoard(strMsg);
            if (ret) {
                m_bConnection = true;
            }
            else {
                m_spDao.EndWork();
            }
        }
        
        return ret;
    }
    
    // 关闭串口
    public boolean CloseSerialPort(StringBuffer strMsg) {
        if (!CheckConnection(strMsg)) return false;
        
        boolean ret = m_keyDao.CloseKeyBoard(strMsg);
        if (ret) {
            m_bConnection = false;
            ret = m_spDao.EndWork();
        } 

        return ret;
    }
    
    boolean CheckConnection(StringBuffer strMsg) {
        if (!m_bConnection) {
            strMsg.append(String.valueOf(SMDataProcess.CErrorCode.ConnectionFails_Key)).append(" (").append(SMDataProcess.CErrorCode.ConnectionFails_Val).append(")");
            return false;
        }
        
        return true;
    }
    
    public byte GetKeyValue() {
        byte ret = 0;
        if (0 != CDataMgrSM.KeyValue) {
            ret = CDataMgrSM.KeyValue;
            CDataMgrSM.KeyValue = 0;
        }
        return ret;
    }
}
