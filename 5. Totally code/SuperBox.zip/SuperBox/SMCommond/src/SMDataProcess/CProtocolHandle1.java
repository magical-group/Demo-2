package SMDataProcess;

import SMProtocol.IProtocolHandle;
import java.util.Arrays;
import txt.CTxtHelp;

public class CProtocolHandle1 implements IProtocolHandle {
    byte[] m_boardItems;
    byte[] m_temp;// 当继电器无变化时跳过
    boolean m_bSuccess;
    boolean m_bPowerInit = true;
    boolean m_bPowerState = false;
    
    @Override
    public void ProtState(String sn, boolean blRun) {
        System.out.println("sn:" + sn + ", Run:" + blRun);
    }

    @Override
    public void ClearData() {
        m_bSuccess = false;
    }
    
    @Override
    public boolean Process(String sn, int cmd, SMProtocol.CByteBuffer bBuffer) {
        // 协议解析
        int iPosition = bBuffer.GetPosition(); boolean heardok = false;

        byte head1 = 0;
        while (bBuffer.HasRemaining())
        {
            head1 = bBuffer.GetByte();
            
            // 0x56版本检测;0x0C继电器状态;0x0D开锁指令;0xFE刷卡指令主动上传;0x14掉电检测主动上传;0xFF主板反馈错误处理
            if ((cmd == 14 && head1 == 86) || head1 == 12 || (cmd == 13 || head1 == 13) || head1 == -2 ||
                head1 == 16 || head1 == 15 || head1 == -3 || head1 == 20 || head1 == -1 || head1 == 22 || head1 == 23) 
            {
                heardok = true;
                break;// 0C 0C 0A 0A 0F 0F 00 04 3D 80 7B 53
            }
            else {
                CTxtHelp.AppendLog("[Error] Failed to parse the serial data:" + head1);// 未能解析的串口数据
            }
        }
        
        if (!bBuffer.HasRemaining()) 
        {
            if (heardok) bBuffer.SetPosition(iPosition);// 头正确继续等待接收
            return false;
        }
        
	int cmdFlg = 0;
        switch (head1)
        {
            // 版本信息(自动添加标示头)
            case 86: cmdFlg = 0x0E;break;
            // 读锁状态
            case 12: cmdFlg = 0x0C; break;
            // 开锁控制
            case 13: cmdFlg = 0x0D; break;
            // IC刷卡
            case -2: cmdFlg = 0xFE; break;
            // 扫描头唤醒
            case 16: cmdFlg = 0x10; break;
            // 扫描头关闭
            case 15: cmdFlg = 0x0F; break;
            // 二维码
            case -3: cmdFlg = 0xFD; break;
            // 掉电检测
            case 20: cmdFlg = 0x14; break;
            // 错误反馈
            case -1: cmdFlg = 0xFF; break;
            // 设置层数
            case 22: cmdFlg = 0x16; break;
            // 获取层数
            case 23: cmdFlg = 0x17; break;
        }

        int len = bBuffer.GetRecvLength() - bBuffer.GetPosition();
        byte[] source = bBuffer.GetByteArray(len);
        if (null == source) { bBuffer.SetPosition(iPosition); return false; }
        source[0]  = head1;
        
        switch (cmdFlg)
        {
            case 0x0E:
                // 版本信息V1.0.0.1
                if (source.length < 6) { bBuffer.SetPosition(iPosition); return false; }
                
                CDataMgrSM.Version = bytetoString(source, 0 , source.length - 1);
                bBuffer.SetPosition(iPosition + 6);// 解析成功后重新定位
                break;
            case 0x0C:
                // 读锁状态
                // 0C 55 FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF F3 
                int baglen = 41;
                if (source.length < baglen) { bBuffer.SetPosition(iPosition); return false; }
                
                if (((byte)0xAA == source[1] || (byte)0x55 == source[1])) {
                    if ((byte)0xF3 == source[baglen - 1]) {
                        byte[] single = new byte[baglen];
                        System.arraycopy(source, 0, single, 0, baglen);
                        ReadLockStatus(single);
                        bBuffer.SetPosition(iPosition + baglen);
                    }
                    else {
                        CTxtHelp.AppendLog("[Error] Garbage Data:0x0C_1");
                    }
                }
                else {
                    CTxtHelp.AppendLog("[Error] Garbage Data:0x0C_2");
                }
                break;
            case 0x0D:
                // 开锁控制
                // 0D AA AA 55 0D
                if (source.length < 5) { bBuffer.SetPosition(iPosition); return false; }
                
                if (((byte)0xAA == source[1] || (byte)0x55 == source[1])) {
                    bBuffer.SetPosition(iPosition + 5);
                }
                else {
                    CTxtHelp.AppendLog("[Error] Garbage Data:0x0D");
                }
                break;
            case 0xFE:
                // 设备主动发送IC卡内容(100003)
                // FE 68 6C 64 01 10 00 03 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 12 21 11 11 D6 EE B8 F0 C1 C1 00 00 00 00 00 00 01 
                if (source.length < 66) { bBuffer.SetPosition(iPosition); return false; }
                
                if ((byte)0x68 == source[1] && (byte)0x6C == source[2] && (byte)0x64 == source[3] && (byte)0x01 == source[4]) {
                    ReadICCard(source);
                    bBuffer.SetPosition(iPosition + 66);
                }
                else {
                    CTxtHelp.AppendLog("[Error] Garbage Data:0xFE");
                }
                break;
            case 0x10:
                // 二维码打开
                // 10 AA 55 0D(正常)
                // 10 AA 55 0C(异常)
                if (source.length < 4) { bBuffer.SetPosition(iPosition); return false; }
                
                if ((byte)0xAA == source[1] && (byte)0x55 == source[2]) {
                    switch (source[3]) {
                        case (byte)0x0D: CDataMgrSM.OpenBarCodeResult = true; CTxtHelp.AppendLog("[Info] Open the scanner success"); break;
                        case (byte)0x0C: CDataMgrSM.OpenBarCodeResult = false; CTxtHelp.AppendLog("[Info] Close the scanner fail"); break;
                        default: CTxtHelp.AppendLog("[Error] Garbage Data:0x10_1"); break;
                    }
                    bBuffer.SetPosition(iPosition + 4);
                } 
                else {
                    CTxtHelp.AppendLog("[Error] Garbage Data:0x10_2");
                }
                break;
            case 0x0F:
                // 二维码关闭
                // 0F AA 55 0D(正常)
                // 0F AA 55 0C(异常)
                if (source.length < 4) { bBuffer.SetPosition(iPosition); return false; }
                
                if ((byte)0xAA == source[1] && (byte)0x55 == source[2]) {
                    switch (source[3]) {
                        case (byte)0x0D: CDataMgrSM.CloseBarCodeResult = true; CTxtHelp.AppendLog("[Info] Close the scanner success"); break;
                        case (byte)0x0C: CDataMgrSM.CloseBarCodeResult = true; CTxtHelp.AppendLog("[Info] Close the scanner fail"); break;
                        default: CTxtHelp.AppendLog("[Error] Garbage Data:0x0F_1"); break;
                    } 
                    bBuffer.SetPosition(iPosition + 4);
                }
                else {
                    CTxtHelp.AppendLog("[Error] Garbage Data:0x0F_2");
                }
                break;
            case 0xFD:
                // 二维码数据(不固定长度,限制最大长度以防止垃圾数据)
                // FD 35 39 32 36 32 35 33 35 37 35 37 35 0D 0A 02 
                if (source.length < 4) { bBuffer.SetPosition(iPosition); return false; }
                
                if ((byte)0x0D != source[source.length - 3] && (byte)0x0A != source[source.length - 2] && (byte)0x02 != source[source.length - 1]) { bBuffer.SetPosition(iPosition); return false; }
                CDataMgrSM.BarCodeValue = bytetoString(source, 1, source.length - 4);
                CTxtHelp.AppendLog("[Info] BarCode Input:" + CDataMgrSM.BarCodeValue);
                break;    
            case 0x14:
                // 掉电检测
                // 0x14  0xAA   无掉电
                // 0x14  0x55   已掉电
                if (source.length < 2) { bBuffer.SetPosition(iPosition); return false; }
                
                switch (source[1]) {
                    case (byte)0xAA: CDataMgrSM.POWER = true; bBuffer.SetPosition(iPosition + 2); break;
                    case (byte)0x55: CDataMgrSM.POWER = false; bBuffer.SetPosition(iPosition + 2); break;
                    default: CTxtHelp.AppendLog("[Error] Garbage Data:0x14"); break;
                }
                
                if (m_bPowerInit || (m_bPowerState != CDataMgrSM.POWER)) {
                    m_bPowerInit = false;
                    m_bPowerState = CDataMgrSM.POWER;
                    CTxtHelp.AppendLog("[Info] Power State:" + CDataMgrSM.POWER);
                }
                break;
            case 0xFF:
                // 0xFF data AA 55 0C(data 1位或者2位)
                if (source.length < 5) { bBuffer.SetPosition(iPosition); return false; }
                
                if ((byte)0xAA == source[2] && (byte)0x55 == source[3] && (byte)0x0C == source[4])  {
                    CTxtHelp.AppendLog("[Error] The mainboard feedback error message(5)：" + source[1]);// 5位错误解析
                    bBuffer.SetPosition(iPosition + 5);
                }
                else if (source.length == 5 && (byte)0xAA == source[3] && (byte)0x55 == source[4]) {
                    bBuffer.SetPosition(iPosition); return false;// 可能反馈的是6位错误
                }
                else  if ((byte)0xAA == source[3] && (byte)0x55 == source[4] && (byte)0x0C == source[5]) {
                    CTxtHelp.AppendLog("[Error] The mainboard feedback error message(6)：" + source[1] + " " + source[2]);// 6位错误解析
                    bBuffer.SetPosition(iPosition + 6);
                }
                else {
                     CTxtHelp.AppendLog("[Error] Garbage Data:0xFF");
                }
                break;
              case 0x16:
                if (source.length < 4) { bBuffer.SetPosition(iPosition); return false; }
                
                if ((byte)0x16 == source[0] && (byte)0x57 == source[1] && (byte)0x0D == source[3]) {
                    CDataMgrSM.SetBoardTypeResult = true;
                    bBuffer.SetPosition(iPosition + 4);
                }
                else {
                    CTxtHelp.AppendLog("[Error] Garbage Data:0x16");
                }
                break;
            case 0x17:
                if (source.length < 4) { bBuffer.SetPosition(iPosition); return false; }
                
                if ((byte)0x17 == source[0] && (byte)0x52 == source[1] && (byte)0x0D == source[3]) {
                    CDataMgrSM.HardBoardType = source[2];
                    bBuffer.SetPosition(iPosition + 4);
                }
                else {
                    CTxtHelp.AppendLog("[Error] Garbage Data:0x17");
                }
                break;  
        }

        if (cmd == cmdFlg) {
            m_bSuccess = true;
        }
        else {
            SMDataProcess.CDeviceDAO.NextReadTime = SMDataProcess.CDeviceDAO.IntervalReadTime + System.currentTimeMillis();
        }
        
        if (bBuffer.HasRemaining()) {
            if (!bBuffer.GetWaitRecvRemain()) {
                Process(sn, cmd, bBuffer);// 剩余数据继续处理
            }
        }
        else {
            bBuffer.Clear();
        }
        
        return m_bSuccess;
    }
    
    void ReadLockStatus(byte[] source){
        if (null == m_boardItems) {
            m_temp = new byte[source.length];
            m_boardItems = new byte[source.length - 3];// 控制板(0C AA ... F3)
            
            int count = 0;
            if (CDataMgrSM.DoubleInput) {
                count = 152 + 1;
            }
            else {
                count = 304 + 1;// 单输入
            }
            
            CDataMgrSM.InitRelay(CDataMgrSM.DoubleInput, count);
        }

        if ((source.length - 3) != m_boardItems.length) return;// 防止主板反馈信息有问题
        if (Arrays.equals(source, m_temp)) return;// 整个继电器无变化时跳过
        
        System.arraycopy(source, 0, m_temp, 0, source.length);
        System.arraycopy(source, 2, m_boardItems, 0, m_boardItems.length);

        int relayIndex = 1;
        int sensorIndex = 1;
        int lockIndex = 1;
        boolean isFlg_Sensor = false;
        
        //System.out.println("====================");
        for (int i = 0; i < m_boardItems.length; i++) {
            int boardval = m_boardItems[i];
            if (m_boardItems[i] < 0) boardval = 256 + m_boardItems[i];

            int ival = Integer.parseInt(Integer.toBinaryString(boardval));
            String str = String.format("%08d", ival);
            //System.out.println(str);

            for(int j = str.length(); j > 0 ; j--) {
                byte relayval = (byte)Integer.parseInt(str.substring(j - 1, j));
                isFlg_Sensor = relayIndex % 2 == 0 ? true : false;
                if (!CDataMgrSM.DoubleInput) isFlg_Sensor = false;// 单输入
                    
                switch (source[1]) {
                    case -86:
                        if (isFlg_Sensor) 
                            CDataMgrSM.SensorItemsLeft[sensorIndex++] = relayval;
                        else
                            CDataMgrSM.LockItemsLeft[lockIndex++] = relayval;
                        break;
                    case 85:
                        if (isFlg_Sensor) 
                            CDataMgrSM.SensorItemsRight[sensorIndex++] = relayval;
                        else
                            CDataMgrSM.LockItemsRight[lockIndex++] = relayval;
                        break;
                }
                 
                relayIndex++;
            }
        }
    }
    
    void ReadICCard(byte[] source){
        String strTemp = "";
        for (int i = 5; i <= 7; i++) {
            if (source[i] < 16) {
                strTemp += "0";
            }
            strTemp +=(Integer.toHexString(source[i]));
        }

        CDataMgrSM.ICValue = strTemp;
        CTxtHelp.AppendLog("[Info] ReadICCard Value:" + CDataMgrSM.ICValue);
    }

    // 十六进制转ascii
    static String bytetoString(byte[] bytearray, int offset, int len) {
        String result = "";
        char temp;

        if (len == 0) len = bytearray.length;
        for (int i = offset; i <= len; i++) {
            temp = (char) bytearray[i];
            result += temp;
        }
        return result;
    }
}
