package SMDataProcess;

import SMProtocol.CByteBuffer;
import SMProtocol.IProtocolHandle;
import txt.CTxtHelp;

public class CProtocolHandle2 implements IProtocolHandle {
    byte[] m_boardItems;
    
    @Override
    public void ProtState(String sn, boolean blRun) {
        System.out.println("sn:" + sn + ", Run:" + blRun);
    }

    @Override
    public void ClearData() {
    }
    
    @Override
    public boolean Process(String sn, int cmd, CByteBuffer bBuffer) {
        // 协议解析
        int iPosition = bBuffer.GetPosition();
     
        if (cmd == 0x34 || cmd == 0x37)
        {
            int len = bBuffer.GetRecvLength();
            byte[] source = bBuffer.GetByteArray(len);
            if (null == source) { bBuffer.SetPosition(iPosition); return false; }

            if (source.length < 8) { bBuffer.SetPosition(iPosition); return false; }
            
            // 02 30 31 30 34 30 35(Activate)
            // 02 30 31 30 34 30 35(Close)
            String msg = "";        
            if ((byte)0x35 == source[7]) 
            { 
                switch (cmd) 
                {
                    case 0x34: CDataMgrSM.ActivateKey = true; msg = "[Info] Metal keyboard, activate the success"; break;
                    case 0x37: CDataMgrSM.CloseKey = true; msg = "[Info] Metal keyboard, close the success"; break;
                    default: msg = "[Error] Garbage Data 1"; break;
                }
               
                CTxtHelp.AppendLog(msg); 
                bBuffer.SetPosition(iPosition + 7);
            }
            else {
                CTxtHelp.AppendLog("[Error] Garbage Data");
            }
        }
        else
        {
            CDataMgrSM.KeyValue = bBuffer.GetByte();
            //CTxtHelp.AppendLog("[Info] Key Input:" + CDataMgrSM.KeyValue);
        }
        
        if (bBuffer.HasRemaining())
        {
            if (!bBuffer.GetWaitRecvRemain())
            {
                Process(sn, cmd, bBuffer);// 剩余数据继续处理
            }
        }
        else
        {
            bBuffer.Clear();
        }
         
        return true;
    }
}
