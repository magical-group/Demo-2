package SMDataProcess;

import SMProtocol.CSPDAO;

public class CDeviceDAO {
	
    CSPDAO m_spDao = null;
    
    static volatile long NextOpenTime = 0;
    static volatile long NextReadTime = 0;
    public static volatile long IntervalOpenTime = 600;// 开锁指令至少间隔600ms 
    public static volatile long IntervalReadTime = 200;
    public static volatile boolean WhenOpenStopQuery = false;// 开锁时停止查询继电器状态
    public static volatile int AfterOpenReadInterval = 200;// 开锁后读取继电器状态时间间隔
    
    public CDeviceDAO(CSPDAO spDao) {
        m_spDao = spDao;
    }
    
    public String GetVersion(StringBuffer strMsg) {
        byte cmd = 0x0E;
        byte[] writeBuffer = new byte[1];
        writeBuffer[0] = cmd;

        m_spDao.Send(cmd, writeBuffer, 2, strMsg);
        
        return CDataMgrSM.Version;
    }
    
    boolean ReadBoxLeft(StringBuffer strMsg) {
        long interval = NextReadTime - System.currentTimeMillis();
        if (interval > 0) try { Thread.sleep(IntervalReadTime); } catch (InterruptedException ex) { }
        
        byte cmd = 0x0C;
        byte[] writeBuffer = new byte[2];
        writeBuffer[0] = cmd;
        writeBuffer[1] = (byte)0xAA;

        int ret = m_spDao.Send(cmd, writeBuffer, 2, strMsg);// 读取左侧控制板
        NextReadTime = IntervalReadTime + System.currentTimeMillis();
        
        return (ret == 0) ? true : false;
    }
    
    boolean ReadBoxRight(StringBuffer strMsg) {
        long interval = NextReadTime - System.currentTimeMillis();
        if (interval > 0) try { Thread.sleep(IntervalReadTime); } catch (InterruptedException ex) { }
        
        byte cmd = 0x0C;
        byte[] writeBuffer = new byte[2];
        writeBuffer[0] = cmd;
        writeBuffer[1] = (byte)0x55;

        int ret = m_spDao.Send(cmd, writeBuffer, 2, strMsg);// 读取左侧控制板
        NextReadTime = IntervalReadTime + System.currentTimeMillis();
        
        return (ret == 0) ? true : false;
    }

    /*********************************************************
    Function:	OpenBarCode
    Describe:	读取掉电信息
    Input:	
    Return:	True:打开;False:未打开
    **********************************************************/
    void ReadPower(StringBuffer strMsg) {
        long interval = NextReadTime - System.currentTimeMillis();
        if (interval > 0) try { Thread.sleep(IntervalReadTime); } catch (InterruptedException ex) { }
        
        // Send:14
        // Recv:14 AA(正常) / 14 55(掉电)
        byte cmd = 0x14;
        byte[] writeBuffer = new byte[1];
        writeBuffer[0] = cmd;
        m_spDao.Send(cmd, writeBuffer, 2, strMsg);
        
        NextReadTime = IntervalReadTime + System.currentTimeMillis();
    }

    /*********************************************************
    Function:	OpenTerminalBox
    Describe:	打开格口
    Input:	relay:继电器号	
    Return:	
    **********************************************************/
    boolean OpenTerminalBox(int side, int relay, StringBuffer strMsg){
        WhenOpenStopQuery = true;
        
        // 控制两次开启时间间隔
        long interval = NextOpenTime - System.currentTimeMillis();
        if (interval > 0) {
            try { Thread.sleep(IntervalOpenTime); } catch (InterruptedException ex) { }
        }
        
        // 开
        // 0D AA 00 01 F2
        String strRelayID = String.format("%04d", relay);
        String num1 = strRelayID.substring(0, 2);
        String num2 = strRelayID.substring(2, 4);
        
        int ival1 = Integer.parseInt(num1.substring(0, 1)) * 16 + Integer.parseInt(num1.substring(1, 2));
        int ival2 = Integer.parseInt(num2.substring(0, 1)) * 16 + Integer.parseInt(num2.substring(1, 2));
        
        byte cmd = 0x0D;
        byte val = (byte) (side == 0 ? 0xAA : 0x55);
        byte[] writeBuffer = new byte[5];
        writeBuffer[0] = cmd;
        writeBuffer[1] = val;
        writeBuffer[2] = (byte) ival1;
        writeBuffer[3] = (byte) ival2;
        writeBuffer[4] = (byte) 0xF2;
        
        m_spDao.Send(cmd, writeBuffer, 2, strMsg);
 
        try { Thread.sleep(AfterOpenReadInterval); } catch (InterruptedException ex) { }
        
        int ret = 1;
        switch (side) {
            case 0: ReadBoxLeft(strMsg); if (null != CDataMgrSM.LockItemsLeft) ret = CDataMgrSM.LockItemsLeft[relay]; break;
            case 1: ReadBoxRight(strMsg); if (null != CDataMgrSM.LockItemsRight) ret = CDataMgrSM.LockItemsRight[relay]; break;
        }

        NextOpenTime = IntervalOpenTime + System.currentTimeMillis();
        NextReadTime = IntervalReadTime + System.currentTimeMillis();
        
        WhenOpenStopQuery = false;
        
        return ret == 0 ? true : false;
    }

    /*********************************************************
    Function:	OpenBarCode
    Describe:	打开扫描设备
    Input:	
    Return:	True:打开;False:未打开
    **********************************************************/
    boolean OpenBarCode(StringBuffer strMsg) {
        CDataMgrSM.OpenBarCodeResult = false;
        
        // Send:10
        // Recv:10 AA 55 0D
        byte cmd = 0x10;
        byte[] writeBuffer = new byte[1];
        writeBuffer[0] = cmd;
        m_spDao.Send(cmd, writeBuffer, 0, strMsg);
        
        return CDataMgrSM.OpenBarCodeResult;
    }
    
    /*********************************************************
    Function:	OpenBarCode
    Describe:	关闭扫描设备
    Input:	
    Return:	True:打开;False:未打开
    **********************************************************/
    boolean CloseBarCode(StringBuffer strMsg) {
        CDataMgrSM.CloseBarCodeResult = false;
        
        // Send:0F
        // Recv:0F AA 55 0D 
        byte cmd = 0x0F;
        byte[] writeBuffer = new byte[1];
        writeBuffer[0] = cmd;
        m_spDao.Send(cmd, writeBuffer, 0, strMsg);
        
        return CDataMgrSM.CloseBarCodeResult;
    }
    
    /*********************************************************
    Function:	SetBoardType
    Describe:	设置层数
    Input:	
    Return:	True:成功;False:失败
    **********************************************************/
    public boolean SetBoardType(int val, StringBuffer strMsg) {
        CDataMgrSM.SetBoardTypeResult = false;
        
        // Send:16 57 08
        // Recv:16 57 08 0D 
        byte cmd = 0x16;
        byte[] writeBuffer = new byte[3];
        writeBuffer[0] = cmd;
        writeBuffer[1] = 0x57;
        writeBuffer[2] = (byte) (val == 8 ? 0x08 : 0x09);
        m_spDao.Send(cmd, writeBuffer, 2, strMsg);
        
        return CDataMgrSM.SetBoardTypeResult;
    }
    
    /*********************************************************
    Function:	SetBoardType
    Describe:	设置层数
    Input:	
    Return:	True:成功;False:失败
    **********************************************************/
    public int ReadBoardType(StringBuffer strMsg) {
        CDataMgrSM.HardBoardType = 0;
        
        // Send:17 52
        // Recv:17 52 08 0D 
        byte cmd = 0x17;
        byte[] writeBuffer = new byte[2];
        writeBuffer[0] = cmd;
        writeBuffer[1] = 0x52;
        m_spDao.Send(cmd, writeBuffer, 2, strMsg);
        
        return CDataMgrSM.HardBoardType;
    }
}
