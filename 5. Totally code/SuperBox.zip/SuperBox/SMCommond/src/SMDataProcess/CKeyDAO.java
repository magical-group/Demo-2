package SMDataProcess;

import SMProtocol.CSPDAO;

public class CKeyDAO {
    
    CSPDAO m_spDao = null;
	
    public CKeyDAO(CSPDAO spDao)
    {
        m_spDao = spDao;
    }
    
    public boolean LoadKeyBoard(StringBuffer strMsg){
        CDataMgrSM.ActivateKey = false;
        
        // 02 30 32 34 35 30 33 34 34
        byte cmd = 0x34;
        byte[] writeBuffer = new byte[9];
        writeBuffer[0] = 0x02;
        writeBuffer[1] = 0x30;
        writeBuffer[2] = 0x32;
        writeBuffer[3] = 0x34;
        writeBuffer[4] = 0x35;
        writeBuffer[5] = 0x30;
        writeBuffer[6] = 0x33;
        writeBuffer[7] = 0x34;
        writeBuffer[8] = cmd;
        
        m_spDao.Send(cmd, writeBuffer, 2, strMsg);
        
        return  CDataMgrSM.ActivateKey;
    }
    
    public boolean CloseKeyBoard(StringBuffer strMsg) {
        CDataMgrSM.CloseKey = false;
        
        // 02 30 32 34 35 30 30 34 37
        byte cmd = 0x37;
        byte[] writeBuffer = new byte[9];
        writeBuffer[0] = 0x02;
        writeBuffer[1] = 0x30;
        writeBuffer[2] = 0x32;
        writeBuffer[3] = 0x34;
        writeBuffer[4] = 0x35;
        writeBuffer[5] = 0x30;
        writeBuffer[6] = 0x30;
        writeBuffer[7] = 0x34;
        writeBuffer[8] = cmd;
        
        m_spDao.Send(cmd, writeBuffer, 2, strMsg);
        
        return  CDataMgrSM.CloseKey;
    }
    
    String GetLastError(){
        return m_spDao.GetLastError();
    }
}
