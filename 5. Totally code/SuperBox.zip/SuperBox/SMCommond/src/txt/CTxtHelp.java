package txt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CTxtHelp {
    static String dataDir = System.getProperty("user.dir") + File.separator + "soft" + File.separator + "log_board";
    
    public static void AppendLog(String newStr) {
        if (SMDataProcess.CDataMgrSM.IsDebug)
            writeTxtFile(dataDir, dataDir + File.separator + new SimpleDateFormat("yyyyMMdd").format(new Date()) + ".txt", newStr, true, true);
    }
    
    public static String GetLogPath() {
        return dataDir;
    }
    
    /**
     * 创建文件
     * 
     */
    static boolean creatTxtFile(String strDir, String filePath) {
        boolean flag = false;

        File file = new File(strDir);
        if(!file.exists()) 
            file.mkdirs();// 目录不存在，则创建相应的目录
        
        File filename = new File(filePath);
        if (!filename.exists()) {
            try {
                filename.createNewFile();
            } 
            catch (IOException e) {
            }
            flag = true;
        }
        
        return flag;
    }
    
    /**
     * 写文件(先读取原有文件内容，然后进行写入操作)
     * @param strDir
     * @param filePath
     * @param newStr
     * @param addtime
     * @param newline
     * @return 
     */
    public static boolean writeTxtFile(String strDir, String filePath, String newStr, boolean addtime, boolean newline) {
        boolean flag = false;
        String filein = "";
        if (addtime) filein = new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(new Date()) + " " ;
        filein = filein + newStr;
        if (newline) filein = filein + System.getProperty("line.separator");
        String temp = "";

        FileInputStream fis = null;
        InputStreamReader isr = null;
        BufferedReader br = null;

        FileOutputStream fos = null;
        PrintWriter pw = null;
        
        try {
            creatTxtFile(strDir, filePath);
        	
            // 文件路径
            File file = new File(filePath);
            // 将文件读入输入流
            fis = new FileInputStream(file);
            isr = new InputStreamReader(fis);
            br = new BufferedReader(isr);
            StringBuilder buf = new StringBuilder();

            // 保存该文件原有的内容
            while ((temp = br.readLine()) != null) {
                buf = buf.append(temp);
                buf = buf.append("\r\n"); // 行与行之间的分隔符 相当于“\n”System.getProperty("line.separator")
            }
            buf.append(filein);
            fos = new FileOutputStream(file);
            pw = new PrintWriter(fos);
            pw.write(buf.toString().toCharArray());
            pw.flush();
            flag = true;
        } 
        catch (IOException e){
            System.out.println("writeTxtFile:" + e.getMessage());
        } 
        finally {
           if (pw != null) {
               pw.close();
           }
           if (fos != null) {
               try { fos.close(); } catch (IOException e) {}
           }
           if (br != null){
               try { br.close(); } catch (IOException e) {}
           }
           if (isr != null){
               try { isr.close(); } catch (IOException e) {}
           }
           if (fis != null) {
               try { fis.close(); } catch (IOException e) {}
           }
       }
       
       System.out.println(filein);
       
       return flag;
   }

   /**
    * 读取数据
     * @param filePath
     * @return 
    */
   public static String ReadTxtFile(String filePath) {
       String strs = "";
       
       try {
           FileReader read = new FileReader(new File(filePath));
           StringBuilder sb = new StringBuilder();
           char ch[] = new char[1024];
           int d = read.read(ch);
           while (d != -1) {
               String str = new String(ch, 0, d);
               sb.append(str);
               d = read.read(ch);
           }
           String a = sb.toString().replaceAll("@@@@@", ",");
           strs = a.substring(0, a.length() -1);
       } 
       catch (FileNotFoundException e) {
       } 
       catch (IOException e){
       }
       
       return strs;
   }
}
