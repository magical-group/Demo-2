package SMProtocol;

public class CCommondFunc {
	
    public static String ToHexString(byte[] bytes, int len)
    {
        String hexString = "";
        if (bytes != null)
        {
            StringBuilder strB = new StringBuilder();

            for (int i = 0; i < len; i++)
            {
                strB.append(Integer.toHexString(bytes[i])).append(" ");
            }
            hexString = strB.toString();
        }

        hexString = hexString.trim();

        return hexString;
    }
	
    /** 
     * 通过byte数组取到int 
     *  
     * @param bb 
     * @param index 
     *            第几位开始 
     * @return 
     */  
    public static int GetInt(byte[] bb, int index) {  
        return (int) ((((bb[index + 3] & 0xff) << 24)  
                | ((bb[index + 2] & 0xff) << 16)  
                | ((bb[index + 1] & 0xff) << 8) | ((bb[index + 0] & 0xff) << 0)));  
    }
    
    public static String GetDateTimeFromTimestamp(long timestamp) {
    	 timestamp = timestamp * 1000;    
    	 return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(timestamp));     
    }
}
